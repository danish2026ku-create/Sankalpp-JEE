# Sankalp JEE — ProGuard / R8 rules

# Keep Room entities
-keep class com.sankalp.jee.data.local.entities.** { *; }

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager$FragmentContextWrapper { *; }

# Keep Compose internals
-keep class androidx.compose.** { *; }

# Keep Glance widget receivers
-keep class androidx.glance.appwidget.** { *; }

# Keep data classes used for JSON/serialization (if any added later)
-keepclassmembers class com.sankalp.jee.domain.model.** { *; }

# Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}
