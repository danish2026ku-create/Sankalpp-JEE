package com.sankalp.jee.di

import android.content.Context
import com.sankalp.jee.data.local.SankalpDao
import com.sankalp.jee.data.local.SankalpDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SankalpDatabase {
        return SankalpDatabase.create(context)
    }

    @Provides
    @Singleton
    fun provideDao(database: SankalpDatabase): SankalpDao {
        return database.dao()
    }
}
