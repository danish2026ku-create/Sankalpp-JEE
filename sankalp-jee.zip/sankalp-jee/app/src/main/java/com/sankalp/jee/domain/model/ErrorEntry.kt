package com.sankalp.jee.domain.model

/**
 * An entry in the Error Book — a mistake logged from practice or mocks.
 *
 * @property id           Unique row ID.
 * @property subject      Subject area.
 * @property chapterId    Optional linked chapter.
 * @property questionDesc Short description of the question.
 * @property correctAns   The correct answer / approach.
 * @property category     Error category.
 * @property mockTestId   Optional link to source mock test.
 * @property loggedAt     Epoch millis when logged.
 * @property reviewCount  Number of times this error has been reviewed.
 * @property isResolved   Whether the student has overcome this error type.
 */
data class ErrorEntry(
    val id: Long = 0,
    val subject: Subject,
    val chapterId: Long? = null,
    val questionDesc: String,
    val correctAns: String,
    val category: ErrorCategory,
    val mockTestId: Long? = null,
    val loggedAt: Long = System.currentTimeMillis(),
    val reviewCount: Int = 0,
    val isResolved: Boolean = false,
)
