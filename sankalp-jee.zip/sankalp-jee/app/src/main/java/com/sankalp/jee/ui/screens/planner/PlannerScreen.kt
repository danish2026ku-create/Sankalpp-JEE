package com.sankalp.jee.ui.screens.planner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.*
import kotlinx.coroutines.flow.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    onNavigateToSyllabus: () -> Unit,
    onNavigateToBacklog: () -> Unit,
    viewModel: PlannerViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Study Planner", style = MaterialTheme.typography.headlineLarge)
        }

        // Today's tasks
        item {
            SectionHeader(
                title = "Today's Plan",
                trailing = {
                    TextButton(onClick = { /* Add task dialog */ }) {
                        Text("+ Add")
                    }
                },
            )
        }

        if (state.todayTasks.isEmpty()) {
            item {
                EmptyState(
                    emoji = "📋",
                    message = "No tasks planned for today.\nAdd a task to get started!",
                )
            }
        } else {
            items(state.todayTasks) { task ->
                SankalpCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = task.isDone,
                            onCheckedChange = { viewModel.toggleTask(task.id) },
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = task.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = if (task.isDone) FontWeight.Normal else FontWeight.SemiBold,
                            )
                            Text(
                                text = "${task.subject.displayName} · ~${task.estimatedMin}m",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }

        // Quick navigation
        item {
            Spacer(Modifier.height(8.dp))
            SectionHeader(title = "More")
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                SankalpCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "📊 Syllabus Tracker",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Track chapter-wise progress",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = onNavigateToSyllabus) {
                        Text("View →")
                    }
                }
                SankalpCard(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "📦 Backlog",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "${state.backlogCount} pending tasks",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = onNavigateToBacklog) {
                        Text("View →")
                    }
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}
