package com.sankalp.jee.domain.model

/**
 * Represents a completed focus/study session.
 *
 * @property id           Unique row ID (Room-assigned).
 * @property subject      Optional subject tag for this session.
 * @property chapterId    Optional linked chapter.
 * @property durationSec  Actual seconds spent focusing.
 * @property startedAt    Epoch millis when the session began.
 * @property focusMode    The mode used during this session.
 * @property focusScore   Computed quality score 0–100 (distraction ratio etc.)
 */
data class FocusSession(
    val id: Long = 0,
    val subject: Subject? = null,
    val chapterId: Long? = null,
    val durationSec: Long,
    val startedAt: Long,
    val focusMode: FocusMode = FocusMode.GENTLE,
    val focusScore: Int = 100,
) {
    val durationMin: Int get() = (durationSec / 60).toInt()
}
