package com.sankalp.jee.ui.screens.practice

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.SankalpTheme

@Composable
fun PracticeScreen(
    onNavigateToMockLog: () -> Unit,
    onNavigateToErrorBook: () -> Unit,
    onNavigateToWeaknessRadar: () -> Unit,
) {
    val themeColors = SankalpTheme.colors

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text("Practice & Analysis", style = MaterialTheme.typography.headlineLarge)
        }

        // Mock Tests
        item {
            SectionHeader(title = "Mock Tests")
        }
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("📝 Log Mock Test", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Record your test results and track improvement",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onNavigateToMockLog) { Text("Log →") }
                }
            }
        }

        // Error Book
        item {
            SectionHeader(title = "Error Analysis")
        }
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("📕 Error Book", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Categorize and review your mistakes",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onNavigateToErrorBook) { Text("View →") }
                }
            }
        }

        // Weakness Radar
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("🎯 Weakness Radar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Identify your weakest areas and priority chapters",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onNavigateToWeaknessRadar) { Text("Analyze →") }
                }
            }
        }

        // Rank Estimator
        item {
            SectionHeader(title = "Rank Estimation")
        }
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Text("🏆 Estimated Rank", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Log at least 3 mock tests to see rank estimation",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
fun MockLogScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Log Mock Test") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            EmptyState(emoji = "📝", message = "Log your mock test scores here")
        }
    }
}

@Composable
fun ErrorBookScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Error Book") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            EmptyState(emoji = "📕", message = "Log your mistakes to identify patterns")
        }
    }
}

@Composable
fun WeaknessRadarScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Weakness Radar") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            EmptyState(emoji = "🎯", message = "Your weakest chapters will appear here based on error patterns and syllabus progress")
        }
    }
}
