package com.sankalp.jee.domain.model

/**
 * A chapter in the JEE syllabus.
 *
 * @property id         Unique row ID.
 * @property name       Chapter name (e.g., "Kinematics").
 * @property subject    Subject this chapter belongs to.
 * @property status     Current mastery status.
 * @property weightage  How heavily this chapter is tested.
 * @property order      Sort order within the subject.
 */
data class Chapter(
    val id: Long = 0,
    val name: String,
    val subject: Subject,
    val status: TopicStatus = TopicStatus.NOT_STARTED,
    val weightage: WeightageTier = WeightageTier.MEDIUM,
    val order: Int = 0,
) {
    /** Progress percentage 0–100. */
    val progressPercent: Int get() = (status.progress * 100).toInt()
}
