package com.sankalp.jee.ui.util

import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

object Formatters {
    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val shortDateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    fun formatDate(millis: Long): String = dateFormat.format(Date(millis))
    fun formatShortDate(millis: Long): String = shortDateFormat.format(Date(millis))
    fun formatTime(millis: Long): String = timeFormat.format(Date(millis))

    fun formatDuration(seconds: Long): String {
        val hours = TimeUnit.SECONDS.toHours(seconds)
        val minutes = TimeUnit.SECONDS.toMinutes(seconds) % 60
        val secs = seconds % 60
        return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, secs)
        else "%02d:%02d".format(minutes, secs)
    }

    fun formatMinutes(totalMin: Long): String {
        val hours = totalMin / 60
        val minutes = totalMin % 60
        return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m"
    }

    fun relativeTime(millis: Long): String {
        val diff = System.currentTimeMillis() - millis
        val days = TimeUnit.MILLISECONDS.toDays(diff)
        return when {
            days == 0L -> "Today"
            days == 1L -> "Yesterday"
            days < 7 -> "${days} days ago"
            days < 30 -> "${days / 7} weeks ago"
            else -> formatShortDate(millis)
        }
    }
}
