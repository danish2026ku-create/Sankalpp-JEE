package com.sankalp.jee.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.sankalp.jee.domain.model.FocusMode
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.domain.model.ThemeId
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sankalp_prefs")

/**
 * Central user preferences store — all onboarding choices, theme, subjects,
 * exam date, blocked apps, focus settings, streaks, etc.
 */
@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val store = context.dataStore

    // ────────────── Keys ──────────────
    private object Keys {
        val ONBOARDING_COMPLETE = booleanPreferencesKey("onboarding_complete")
        val EXAM_DATE_MILLIS = longPreferencesKey("exam_date_millis")
        val SELECTED_SUBJECTS = stringSetPreferencesKey("selected_subjects")
        val THEME_ID = stringPreferencesKey("theme_id")
        val FOCUS_MODE = stringPreferencesKey("focus_mode")
        val FOCUS_DURATION_MIN = intPreferencesKey("focus_duration_min")
        val SHORT_BREAK_MIN = intPreferencesKey("short_break_min")
        val LONG_BREAK_MIN = intPreferencesKey("long_break_min")
        val BLOCKED_PACKAGES = stringSetPreferencesKey("blocked_packages")
        val STRICT_MODE = booleanPreferencesKey("strict_mode")
        val NOTIFICATION_GUARD = booleanPreferencesKey("notification_guard")
        val CURRENT_STREAK = intPreferencesKey("current_streak")
        val LONGEST_STREAK = intPreferencesKey("longest_streak")
        val LAST_STUDY_DATE = longPreferencesKey("last_study_date")
        val TOTAL_FOCUS_MINUTES = longPreferencesKey("total_focus_minutes")
        val MUSIC_VOLUME = floatPreferencesKey("music_volume")
        val SOUNDSCAPE_ID = stringPreferencesKey("soundscape_id")
        val AUTO_FOCUS_START_HOUR = intPreferencesKey("auto_focus_start_hour")
        val AUTO_FOCUS_END_HOUR = intPreferencesKey("auto_focus_end_hour")
        val AUTO_FOCUS_ENABLED = booleanPreferencesKey("auto_focus_enabled")
    }

    // ────────────── Flows ──────────────

    val onboardingComplete: Flow<Boolean> =
        store.data.map { it[Keys.ONBOARDING_COMPLETE] ?: false }

    val examDateMillis: Flow<Long?> =
        store.data.map { it[Keys.EXAM_DATE_MILLIS] }

    val selectedSubjects: Flow<Set<Subject>> =
        store.data.map { prefs ->
            prefs[Keys.SELECTED_SUBJECTS]?.mapNotNull {
                runCatching { Subject.valueOf(it) }.getOrNull()
            }?.toSet() ?: emptySet()
        }

    val themeId: Flow<ThemeId> =
        store.data.map { prefs ->
            prefs[Keys.THEME_ID]?.let {
                runCatching { ThemeId.valueOf(it) }.getOrNull()
            } ?: ThemeId.MIDNIGHT_LIBRARY
        }

    val focusMode: Flow<FocusMode> =
        store.data.map { prefs ->
            prefs[Keys.FOCUS_MODE]?.let {
                runCatching { FocusMode.valueOf(it) }.getOrNull()
            } ?: FocusMode.STANDARD
        }

    val focusDurationMin: Flow<Int> =
        store.data.map { it[Keys.FOCUS_DURATION_MIN] ?: 52 }

    val shortBreakMin: Flow<Int> =
        store.data.map { it[Keys.SHORT_BREAK_MIN] ?: 10 }

    val longBreakMin: Flow<Int> =
        store.data.map { it[Keys.LONG_BREAK_MIN] ?: 20 }

    val blockedPackages: Flow<Set<String>> =
        store.data.map { it[Keys.BLOCKED_PACKAGES] ?: emptySet() }

    val strictMode: Flow<Boolean> =
        store.data.map { it[Keys.STRICT_MODE] ?: false }

    val notificationGuard: Flow<Boolean> =
        store.data.map { it[Keys.NOTIFICATION_GUARD] ?: false }

    val currentStreak: Flow<Int> =
        store.data.map { it[Keys.CURRENT_STREAK] ?: 0 }

    val longestStreak: Flow<Int> =
        store.data.map { it[Keys.LONGEST_STREAK] ?: 0 }

    val lastStudyDate: Flow<Long?> =
        store.data.map { it[Keys.LAST_STUDY_DATE] }

    val totalFocusMinutes: Flow<Long> =
        store.data.map { it[Keys.TOTAL_FOCUS_MINUTES] ?: 0L }

    val musicVolume: Flow<Float> =
        store.data.map { it[Keys.MUSIC_VOLUME] ?: 0.5f }

    val soundscapeId: Flow<String?> =
        store.data.map { it[Keys.SOUNDSCAPE_ID] }

    val autoFocusEnabled: Flow<Boolean> =
        store.data.map { it[Keys.AUTO_FOCUS_ENABLED] ?: false }

    val autoFocusStartHour: Flow<Int> =
        store.data.map { it[Keys.AUTO_FOCUS_START_HOUR] ?: 6 }

    val autoFocusEndHour: Flow<Int> =
        store.data.map { it[Keys.AUTO_FOCUS_END_HOUR] ?: 22 }

    // ────────────── Writers ──────────────

    suspend fun setOnboardingComplete(value: Boolean) {
        store.edit { it[Keys.ONBOARDING_COMPLETE] = value }
    }

    suspend fun setExamDate(millis: Long) {
        store.edit { it[Keys.EXAM_DATE_MILLIS] = millis }
    }

    suspend fun setSelectedSubjects(subjects: Set<Subject>) {
        store.edit { it[Keys.SELECTED_SUBJECTS] = subjects.map { s -> s.name }.toSet() }
    }

    suspend fun setThemeId(theme: ThemeId) {
        store.edit { it[Keys.THEME_ID] = theme.name }
    }

    suspend fun setFocusMode(mode: FocusMode) {
        store.edit { it[Keys.FOCUS_MODE] = mode.name }
    }

    suspend fun setFocusDurationMin(minutes: Int) {
        store.edit { it[Keys.FOCUS_DURATION_MIN] = minutes }
    }

    suspend fun setBlockedPackages(packages: Set<String>) {
        store.edit { it[Keys.BLOCKED_PACKAGES] = packages }
    }

    suspend fun setStrictMode(enabled: Boolean) {
        store.edit { it[Keys.STRICT_MODE] = enabled }
    }

    suspend fun setNotificationGuard(enabled: Boolean) {
        store.edit { it[Keys.NOTIFICATION_GUARD] = enabled }
    }

    suspend fun updateStreak(currentStreak: Int, longestStreak: Int, lastDate: Long) {
        store.edit {
            it[Keys.CURRENT_STREAK] = currentStreak
            it[Keys.LONGEST_STREAK] = longestStreak
            it[Keys.LAST_STUDY_DATE] = lastDate
        }
    }

    suspend fun addFocusMinutes(minutes: Long) {
        store.edit {
            val current = it[Keys.TOTAL_FOCUS_MINUTES] ?: 0L
            it[Keys.TOTAL_FOCUS_MINUTES] = current + minutes
        }
    }

    suspend fun setMusicVolume(volume: Float) {
        store.edit { it[Keys.MUSIC_VOLUME] = volume }
    }

    suspend fun setSoundscapeId(id: String?) {
        store.edit {
            if (id != null) it[Keys.SOUNDSCAPE_ID] = id
            else it.remove(Keys.SOUNDSCAPE_ID)
        }
    }

    suspend fun setAutoFocus(enabled: Boolean, startHour: Int, endHour: Int) {
        store.edit {
            it[Keys.AUTO_FOCUS_ENABLED] = enabled
            it[Keys.AUTO_FOCUS_START_HOUR] = startHour
            it[Keys.AUTO_FOCUS_END_HOUR] = endHour
        }
    }
}
