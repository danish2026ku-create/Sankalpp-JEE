package com.sankalp.jee.data.local

import com.sankalp.jee.data.local.entities.ChapterEntity
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.domain.model.TopicStatus
import com.sankalp.jee.domain.model.WeightageTier

/**
 * Seed data — the complete JEE Main + Advanced syllabus, organised by
 * subject and chapter with approximate weightage tiers.
 *
 * Weightage tiers are based on recent years' question distribution:
 *   HIGH   = 5+ questions per year on average
 *   MEDIUM = 2–4 questions per year
 *   LOW    = 0–1 questions per year
 */
object SeedData {

    fun chapters(): List<ChapterEntity> = buildList {
        var order = 0

        // ═══════════════════════════════════════════════
        //  PHYSICS
        // ═══════════════════════════════════════════════
        addAll(listOf(
            ChapterEntity(name = "Units and Measurements", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.LOW.name, order = order++),
            ChapterEntity(name = "Kinematics", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Laws of Motion", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Work, Energy and Power", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Rotational Motion", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Gravitation", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Properties of Solids and Liquids", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Thermodynamics", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Kinetic Theory of Gases", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Oscillations and Waves", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Electrostatics", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Current Electricity", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Magnetic Effects of Current", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Electromagnetic Induction", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Alternating Current", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Electromagnetic Waves", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.LOW.name, order = order++),
            ChapterEntity(name = "Optics", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Dual Nature of Matter", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Atoms and Nuclei", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Electronic Devices", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Communication Systems", subject = Subject.PHYSICS.name,
                weightage = WeightageTier.LOW.name, order = order++),
        ))

        // ═══════════════════════════════════════════════
        //  CHEMISTRY
        // ═══════════════════════════════════════════════
        // Physical Chemistry
        addAll(listOf(
            ChapterEntity(name = "Some Basic Concepts", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Atomic Structure", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Chemical Bonding", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Chemical Thermodynamics", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Equilibrium", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Solutions", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Electrochemistry", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Chemical Kinetics", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Surface Chemistry", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.LOW.name, order = order++),
        ))
        // Inorganic Chemistry
        addAll(listOf(
            ChapterEntity(name = "Classification of Elements", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "p-Block Elements", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "d and f Block Elements", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Coordination Compounds", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Metallurgy", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.LOW.name, order = order++),
        ))
        // Organic Chemistry
        addAll(listOf(
            ChapterEntity(name = "General Organic Chemistry", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Hydrocarbons", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Haloalkanes and Haloarenes", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Alcohols, Phenols and Ethers", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Aldehydes, Ketones and Carboxylic Acids", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Amines", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Biomolecules", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.LOW.name, order = order++),
            ChapterEntity(name = "Polymers", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.LOW.name, order = order++),
            ChapterEntity(name = "Chemistry in Everyday Life", subject = Subject.CHEMISTRY.name,
                weightage = WeightageTier.LOW.name, order = order++),
        ))

        // ═══════════════════════════════════════════════
        //  MATHEMATICS
        // ═══════════════════════════════════════════════
        addAll(listOf(
            ChapterEntity(name = "Sets, Relations and Functions", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Complex Numbers", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Sequences and Series", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Quadratic Equations", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Matrices and Determinants", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Permutations and Combinations", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Binomial Theorem", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Trigonometry", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Limits and Continuity", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Differential Calculus", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Applications of Derivatives", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Integral Calculus", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Differential Equations", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Coordinate Geometry", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Vectors", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Three-Dimensional Geometry", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.HIGH.name, order = order++),
            ChapterEntity(name = "Statistics and Probability", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.MEDIUM.name, order = order++),
            ChapterEntity(name = "Mathematical Reasoning", subject = Subject.MATHEMATICS.name,
                weightage = WeightageTier.LOW.name, order = order++),
        ))
    }
}
