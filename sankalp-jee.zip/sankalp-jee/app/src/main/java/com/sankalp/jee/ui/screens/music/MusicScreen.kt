package com.sankalp.jee.ui.screens.music

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sankalp.jee.data.music.SoundscapeCatalog
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.SankalpTheme
import kotlinx.coroutines.flow.collectAsState

@Composable
fun MusicScreen(
    onNavigateToSoundscapes: () -> Unit,
    onBack: () -> Unit,
    viewModel: MusicViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
    ) {
        Text("Study Music", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))

        // Mini player (if playing)
        if (state.isPlaying) {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🎵", style = MaterialTheme.typography.displayMedium)
                    Spacer(Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(state.currentName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Playing", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { viewModel.pause() }) { Text("Pause") }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        SectionHeader(title = "Soundscapes")

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(SoundscapeCatalog.all) { soundscape ->
                SankalpCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            when (soundscape.category) {
                                com.sankalp.jee.data.music.Soundscape.Category.NATURE -> "🌿"
                                com.sankalp.jee.data.music.Soundscape.Category.URBAN -> "☕"
                                com.sankalp.jee.data.music.Soundscape.Category.FOCUSSOUND -> "🎧"
                                com.sankalp.jee.data.music.Soundscape.Category.BINAURAL -> "🧠"
                            },
                            style = MaterialTheme.typography.titleLarge,
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(soundscape.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(soundscape.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { viewModel.play(soundscape.id, soundscape.displayName) }) {
                            Text("▶", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
fun SoundscapesScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Soundscapes") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Browse all bundled soundscapes",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
