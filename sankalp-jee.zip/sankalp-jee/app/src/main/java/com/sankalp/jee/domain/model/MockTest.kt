package com.sankalp.jee.domain.model

/**
 * A logged mock test result.
 *
 * @property id              Unique row ID.
 * @property testName        User-given name or source.
 * @property takenAt         Epoch millis when the test was taken.
 * @property totalQuestions  Total number of questions.
 * @property attempted       Number of questions attempted.
 * @property correct         Number of correct answers.
 * @property incorrect       Number of incorrect answers.
 * @property physicsCorrect  Correct in Physics section.
 * @property physicsTotal    Total in Physics section.
 * @property chemistryCorrect Correct in Chemistry section.
 * @property chemistryTotal  Total in Chemistry section.
 * @property mathsCorrect    Correct in Maths section.
 * @property mathsTotal      Total in Maths section.
 * @property totalMarks      Marks obtained.
 * @property maxMarks        Maximum possible marks.
 * @property timeTakenMin    Time taken in minutes.
 */
data class MockTest(
    val id: Long = 0,
    val testName: String,
    val takenAt: Long,
    val totalQuestions: Int = 75,
    val attempted: Int = 0,
    val correct: Int = 0,
    val incorrect: Int = 0,
    val physicsCorrect: Int = 0,
    val physicsTotal: Int = 25,
    val chemistryCorrect: Int = 0,
    val chemistryTotal: Int = 25,
    val mathsCorrect: Int = 0,
    val mathsTotal: Int = 25,
    val totalMarks: Float = 0f,
    val maxMarks: Float = 300f,
    val timeTakenMin: Int = 180,
) {
    /** JEE marking: +4 correct, -1 incorrect. */
    val computedMarks: Float
        get() = correct * 4f - incorrect * 1f

    val accuracy: Float
        get() = if (attempted > 0) correct.toFloat() / attempted else 0f

    val percentile: Float
        get() {
            // Simplified rank estimation based on marks percentage
            val pct = totalMarks / maxMarks
            return when {
                pct >= 0.85f -> 99.5f
                pct >= 0.70f -> 98.0f
                pct >= 0.55f -> 95.0f
                pct >= 0.40f -> 90.0f
                pct >= 0.30f -> 85.0f
                pct >= 0.20f -> 75.0f
                else -> 60.0f
            }
        }
}
