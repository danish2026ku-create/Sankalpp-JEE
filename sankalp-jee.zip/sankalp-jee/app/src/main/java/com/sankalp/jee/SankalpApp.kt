package com.sankalp.jee

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.sankalp.jee.service.FocusSessionService
import com.sankalp.jee.service.work.BootReceiver
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

/**
 * Sankalp JEE Application class.
 *
 * Initializes Hilt DI and WorkManager.
 */
@HiltAndroidApp
class SankalpApp : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override fun onCreate() {
        super.onCreate()

        // Create notification channel for focus timer
        FocusSessionService.createNotificationChannel(this)

        // Schedule periodic workers
        BootReceiver.scheduleWorkers(this)
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()
}
