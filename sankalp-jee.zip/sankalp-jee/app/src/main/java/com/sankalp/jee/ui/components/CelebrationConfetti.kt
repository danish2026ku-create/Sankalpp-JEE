package com.sankalp.jee.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

/**
 * Celebration confetti animation — shown when milestones are hit.
 */
@Composable
fun CelebrationConfetti(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    colors: List<Color> = listOf(
        Color(0xFF7C9CFF), Color(0xFFE8C49A), Color(0xFFF97316),
        Color(0xFF22C55E), Color(0xFFF472B6), Color(0xFF22D3EE),
    ),
) {
    if (!isActive) return

    val infiniteTransition = rememberInfiniteTransition(label = "confetti")
    val progress by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2000), RepeatMode.Restart),
        label = "confetti_progress",
    )

    val particles = remember {
        List(40) {
            Triple(
                Random.nextFloat(),  // x position ratio
                Random.nextFloat() * 0.3f, // y start
                colors[Random.nextInt(colors.size)],
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        particles.forEach { (xRatio, yStart, color) ->
            val y = yStart + progress * 1.2f
            val x = xRatio + (progress * 0.1f * if (xRatio > 0.5f) 1 else -1)
            drawCircle(
                color = color.copy(alpha = (1f - progress).coerceIn(0f, 1f)),
                radius = 4f,
                center = Offset(x * size.width, y * size.height),
            )
        }
    }
}
