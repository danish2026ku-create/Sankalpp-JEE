package com.sankalp.jee.domain.model

/**
 * Ten themes — each with a unique palette and live background style.
 */
enum class ThemeId(val displayName: String) {
    MIDNIGHT_LIBRARY("Midnight Library"),
    TEMPLE_DAWN("Temple Dawn"),
    MONSOON_STUDY("Monsoon Study"),
    KESAR("Kesar"),
    NEELKANTH("Neelkanth"),
    FOREST_ASHRAM("Forest Ashram"),
    PAPER_AND_INK("Paper & Ink"),
    AURORA_NIGHTS("Aurora Nights"),
    COPPER_DUSK("Copper Dusk"),
    EMERALD_FOCUS("Emerald Focus"),
    AUTO("Auto (Time of Day)");

    /** For Auto mode: select bright theme before 17:00, dark/calm after. */
    fun resolveForTime(hour: Int): ThemeId {
        if (this != AUTO) return this
        return if (hour < 17) PAPER_AND_INK else MIDNIGHT_LIBRARY
    }
}
