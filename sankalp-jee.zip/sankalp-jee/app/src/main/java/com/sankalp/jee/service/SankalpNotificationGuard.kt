package com.sankalp.jee.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/**
 * Sankalp Notification Guard — suppresses distracting notifications
 * during focus sessions when Notification Guard is enabled.
 */
@AndroidEntryPoint
class SankalpNotificationGuard : NotificationListenerService() {

    @Inject
    lateinit var prefsRepository: UserPreferencesRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var isGuardActive = false
    private var allowedPackages = setOf(
        "com.sankalp.jee",          // Always allow Sankalp
        "com.android.phone",         // Always allow phone calls
        "com.android.dialer",        // Dialer
        "com.google.android.dialer", // Google Dialer
    )

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (!isGuardActive) return
        sbn ?: return

        val packageName = sbn.packageName
        if (packageName !in allowedPackages) {
            // Cancel (suppress) the notification
            cancelNotification(sbn.key)
        }
    }

    override fun onListenerDisconnected() {
        instance = null
        serviceScope.cancel()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        instance = null
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        var instance: SankalpNotificationGuard? = null
            private set

        fun activate(extraAllowed: Set<String> = emptySet()) {
            instance?.apply {
                isGuardActive = true
                allowedPackages = allowedPackages + extraAllowed
            }
        }

        fun deactivate() {
            instance?.apply {
                isGuardActive = false
            }
        }
    }
}
