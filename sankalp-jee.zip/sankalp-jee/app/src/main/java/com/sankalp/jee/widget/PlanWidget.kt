package com.sankalp.jee.widget

import android.content.Context
import androidx.glance.*
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.*

class PlanWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .background(Color(0xFF0E1116)),
            ) {
                Text(
                    text = "Today's Plan",
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ColorProvider(0xFF7C9CFF)),
                )
                Spacer(modifier = GlanceModifier.height(8.dp))
                Text(
                    text = "No tasks planned",
                    style = TextStyle(fontSize = 14.sp, color = ColorProvider(0xFFE8C49A)),
                )
            }
        }
    }
}

class PlanWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = PlanWidget()
}
