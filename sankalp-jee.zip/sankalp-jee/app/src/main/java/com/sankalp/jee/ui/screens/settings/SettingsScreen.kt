package com.sankalp.jee.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.SankalpTheme

@Composable
fun SettingsScreen(
    onNavigateToThemePicker: () -> Unit,
    onNavigateToBackup: () -> Unit,
    onBack: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Settings", style = MaterialTheme.typography.headlineLarge)
        }

        // Theme
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("🎨 Theme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Customize your study environment",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onNavigateToThemePicker) { Text("Choose →") }
                }
            }
        }

        // Backup
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("💾 Backup & Restore", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Export or import your data",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onNavigateToBackup) { Text("Manage →") }
                }
            }
        }

        // About
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Text("About", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Sankalp JEE v1.0.0", style = MaterialTheme.typography.bodyMedium)
                Text("Free, offline-first study companion", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(4.dp))
                Text("\"Resolve to Rise\" — Sankalp 🪔", style = MaterialTheme.typography.bodyMedium,
                    color = SankalpTheme.colors.themeAccent)
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
fun ThemePickerScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Choose Theme") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val themes = listOf(
                "Midnight Library" to "🌌",
                "Temple Dawn" to "🌅",
                "Monsoon Study" to "🌧",
                "Kesar" to "🧡",
                "Neelkanth" to "💙",
                "Forest Ashram" to "🌿",
                "Paper & Ink" to "📜",
                "Aurora Nights" to "🌌",
                "Copper Dusk" to "🔶",
                "Emerald Focus" to "💚",
                "Auto (Time of Day)" to "⏰",
            )
            items(themes.size) { index ->
                val (name, emoji) = themes[index]
                SankalpCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(emoji, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.width(12.dp))
                        Text(name, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun BackupScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Backup & Restore") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Text("💾 Export Data", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Save all your progress, notes, and settings to a local file.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { /* Export */ }) { Text("Export") }
            }
            Spacer(Modifier.height(16.dp))
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Text("📂 Import Data", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("Restore from a previously exported backup file.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { /* Import */ }) { Text("Import") }
            }
        }
    }
}
