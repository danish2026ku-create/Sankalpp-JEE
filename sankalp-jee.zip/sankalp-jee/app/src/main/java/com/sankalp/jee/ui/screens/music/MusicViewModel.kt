package com.sankalp.jee.ui.screens.music

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sankalp.jee.data.music.MusicRepository
import com.sankalp.jee.data.music.SoundscapeCatalog
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MusicUiState(
    val isPlaying: Boolean = false,
    val currentName: String = "",
    val volume: Float = 0.5f,
)

@HiltViewModel
class MusicViewModel @Inject constructor(
    private val musicRepo: MusicRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(MusicUiState())
    val state: StateFlow<MusicUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            musicRepo.state.collect { playbackState ->
                _state.value = _state.value.copy(
                    isPlaying = playbackState.isPlaying,
                    currentName = playbackState.currentSoundscape?.displayName ?: "",
                    volume = playbackState.volume,
                )
            }
        }
    }

    fun play(id: String, name: String) {
        val soundscape = SoundscapeCatalog.findById(id) ?: return
        musicRepo.play(soundscape)
        _state.value = _state.value.copy(isPlaying = true, currentName = name)
    }

    fun pause() {
        musicRepo.pause()
        _state.value = _state.value.copy(isPlaying = false)
    }
}
