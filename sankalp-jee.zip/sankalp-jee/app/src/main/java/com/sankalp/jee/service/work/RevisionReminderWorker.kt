package com.sankalp.jee.service.work

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sankalp.jee.MainActivity
import com.sankalp.jee.R
import com.sankalp.jee.data.local.SankalpDao
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

/**
 * Revision Reminder Worker — checks for due flashcards and sends
 * a reminder notification if there are items to revise.
 */
@HiltWorker
class RevisionReminderWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted workerParams: WorkerParameters,
    private val dao: SankalpDao,
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val now = System.currentTimeMillis()
        val dueCount = dao.countDueFlashcards(now).first()

        if (dueCount > 0) {
            sendRevisionNotification(dueCount)
        }

        return Result.success()
    }

    private fun sendRevisionNotification(dueCount: Int) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("navigate_to", "revision")
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val notification = NotificationCompat.Builder(context, "sankalp_reminders")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Sankalp — $dueCount cards need revision")
            .setContentText("Your SM-2 schedule has items due. Don't let them pile up!")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(REVISION_REMINDER_ID, notification)
    }

    companion object {
        const val REVISION_REMINDER_ID = 2002
        const val WORK_NAME = "revision_reminder"
    }
}
