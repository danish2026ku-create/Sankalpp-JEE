package com.sankalp.jee.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sankalp.jee.domain.model.*

@Entity(tableName = "error_entries")
data class ErrorEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val chapterId: Long? = null,
    val questionDesc: String,
    val correctAns: String,
    val category: String,
    val mockTestId: Long? = null,
    val loggedAt: Long = System.currentTimeMillis(),
    val reviewCount: Int = 0,
    val isResolved: Boolean = false,
) {
    fun toDomain() = ErrorEntry(
        id = id,
        subject = runCatching { Subject.valueOf(subject) }.getOrDefault(Subject.PHYSICS),
        chapterId = chapterId,
        questionDesc = questionDesc,
        correctAns = correctAns,
        category = runCatching { ErrorCategory.valueOf(category) }.getOrDefault(ErrorCategory.CONCEPTUAL),
        mockTestId = mockTestId,
        loggedAt = loggedAt,
        reviewCount = reviewCount,
        isResolved = isResolved,
    )

    companion object {
        fun fromDomain(e: ErrorEntry) = ErrorEntryEntity(
            id = e.id, subject = e.subject.name, chapterId = e.chapterId,
            questionDesc = e.questionDesc, correctAns = e.correctAns,
            category = e.category.name, mockTestId = e.mockTestId,
            loggedAt = e.loggedAt, reviewCount = e.reviewCount, isResolved = e.isResolved,
        )
    }
}
