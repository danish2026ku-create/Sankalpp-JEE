package com.sankalp.jee.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import com.sankalp.jee.data.rules.ReelsRules
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/**
 * Sankalp Guardian — the Accessibility Service that blocks distracting apps
 * during focus sessions.
 *
 * This service monitors foreground app changes and immediately redirects
 * the user back to Sankalp when a blocked app is opened.
 *
 * It also detects reels/shorts scrolling via view-id matching and
 * shows an interstitial overlay.
 */
@AndroidEntryPoint
class SankalpGuardianService : AccessibilityService() {

    @Inject
    lateinit var prefsRepository: UserPreferencesRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var isFocusActive = false
    private var blockedPackages = emptySet<String>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceScope.launch {
            blockedPackages = prefsRepository.blockedPackages.first()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isFocusActive) return
        event ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val packageName = event.packageName?.toString() ?: return
                val className = event.className?.toString() ?: ""

                // Check if this is a blocked app
                if (packageName in blockedPackages && packageName != applicationContext.packageName) {
                    handleBlockedApp(packageName)
                    return
                }

                // Check for reels/shorts detection
                val rule = ReelsRules.findRule(packageName)
                if (rule != null) {
                    detectReelsScrolling(rule, className)
                }
            }
        }
    }

    private fun handleBlockedApp(packageName: String) {
        // Send user back to Sankalp with a warning
        val intent = packageManager.getLaunchIntentForPackage(applicationContext.packageName)
        intent?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("blocked_app", packageName)
            putExtra("guardian_event", "blocked")
        }
        startActivity(intent)
    }

    private fun detectReelsScrolling(rule: ReelsRules.Rule, className: String) {
        // Check if the active activity matches a reels activity
        if (className in rule.activityNames) {
            // Reels detected — show intervention
            val intent = packageManager.getLaunchIntentForPackage(applicationContext.packageName)
            intent?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("guardian_event", "reels_detected")
                putExtra("detected_app", rule.appName)
            }
            startActivity(intent)
        }
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    override fun onDestroy() {
        instance = null
        serviceScope.cancel()
        super.onDestroy()
    }

    // ────────────── Public API (called from FocusSessionService) ──────────────

    companion object {
        var instance: SankalpGuardianService? = null
            private set

        fun activate(packages: Set<String>) {
            instance?.apply {
                isFocusActive = true
                blockedPackages = packages
            }
        }

        fun deactivate() {
            instance?.apply {
                isFocusActive = false
                blockedPackages = emptySet()
            }
        }
    }
}
