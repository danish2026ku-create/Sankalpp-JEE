package com.sankalp.jee.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/**
 * Shape tokens — consistent border radii.
 */
object SankalpShapes {
    val sm = RoundedCornerShape(8.dp)
    val md = RoundedCornerShape(12.dp)
    val lg = RoundedCornerShape(16.dp)
    val xl = RoundedCornerShape(24.dp)
    val full = RoundedCornerShape(999.dp)
}

fun sankalpMaterial3Shapes(): Shapes = Shapes(
    extraSmall = SankalpShapes.sm,
    small = SankalpShapes.md,
    medium = SankalpShapes.lg,
    large = SankalpShapes.xl,
    extraLarge = SankalpShapes.full,
)
