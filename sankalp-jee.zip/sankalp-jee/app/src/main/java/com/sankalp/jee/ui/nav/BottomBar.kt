package com.sankalp.jee.ui.nav

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sankalp.jee.ui.theme.SankalpTheme

/**
 * Sankalp bottom navigation bar — 5 main destinations.
 */
@Composable
fun SankalpBottomBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    NavigationBar(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 3.dp,
    ) {
        bottomNavItems.forEach { item ->
            val selected = currentRoute == item.route
            val contentColor by animateColorAsState(
                targetValue = if (selected) MaterialTheme.colorScheme.primary
                              else MaterialTheme.colorScheme.onSurfaceVariant,
                label = "nav_color",
            )

            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = {
                    // In production, use actual Material icons
                    Text(
                        text = when (item.iconRes) {
                            "home" -> "⌂"
                            "timer" -> "◷"
                            "calendar" -> "▦"
                            "quiz" -> "✎"
                            "book" -> "◉"
                            else -> "•"
                        },
                        style = MaterialTheme.typography.titleLarge,
                        color = contentColor,
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = contentColor,
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = SankalpTheme.colors.themeAccent,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                ),
            )
        }
    }
}
