package com.sankalp.jee.domain.model

/**
 * JEE subjects with their accent colours.
 */
enum class Subject(val displayName: String, val accentHex: Long) {
    PHYSICS("Physics", 0xFF60A5FA),
    CHEMISTRY("Chemistry", 0xFF34D399),
    MATHEMATICS("Mathematics", 0xFFF472B6);

    companion object {
        fun fromOrdinal(o: Int): Subject = entries[o]
    }
}
