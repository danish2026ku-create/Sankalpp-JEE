package com.sankalp.jee.domain.model

/**
 * Categorisation for errors found in mock tests / practice.
 */
enum class ErrorCategory(val displayName: String) {
    CONCEPTUAL("Conceptual Gap"),
    CALCULATION("Calculation Mistake"),
    SILLY("Silly Mistake"),
    TIME_PRESSURE("Time Pressure"),
    UNATTEMPTED_KNOWN("Unattempted (Known)"),
    UNATTEMPTED_UNKNOWN("Unattempted (Unknown)");
}
