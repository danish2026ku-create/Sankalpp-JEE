package com.sankalp.jee.domain.model

/**
 * Focus mode determines the aggressiveness of distraction blocking.
 */
enum class FocusMode(val displayName: String, val description: String) {
    /** No blocking — pure timer. */
    GENTLE("Gentle", "Just a timer, no blocking"),

    /** Block selected apps, allow all notifications. */
    STANDARD("Standard", "Block selected apps"),

    /** Block apps AND silence notifications. */
    STRICT("Strict", "Block apps + silence notifications"),

    /** Block apps, silence notifications, prevent uninstall of blocker. */
    LOCKDOWN("Lockdown", "Full lockdown — no escape until timer ends");
}
