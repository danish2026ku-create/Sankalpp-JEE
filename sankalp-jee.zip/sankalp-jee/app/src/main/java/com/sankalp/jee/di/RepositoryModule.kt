package com.sankalp.jee.di

import com.sankalp.jee.data.local.SankalpDao
import com.sankalp.jee.data.local.SeedData
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Singleton

/**
 * Provides repositories and seeds initial data on first launch.
 */
@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Provides
    @Singleton
    fun provideSeedInitializer(
        dao: SankalpDao,
        prefs: UserPreferencesRepository,
    ): SeedInitializer {
        return SeedInitializer(dao, prefs).also {
            appScope.launch { it.seedIfNeeded() }
        }
    }
}

/**
 * Seeds the syllabus on first launch (when no chapters exist yet).
 */
class SeedInitializer(
    private val dao: SankalpDao,
    private val prefs: UserPreferencesRepository,
) {
    suspend fun seedIfNeeded() {
        // Check if we already have chapters
        var hasChapters = false
        dao.getAllChapters().collect { list ->
            hasChapters = list.isNotEmpty()
            return@collect // Just need first emission
        }
        if (!hasChapters) {
            dao.insertChapters(SeedData.chapters())
        }
    }
}
