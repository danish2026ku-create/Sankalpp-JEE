package com.sankalp.jee.service.work

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sankalp.jee.MainActivity
import com.sankalp.jee.R
import com.sankalp.jee.data.local.SankalpDao
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.util.Calendar

/**
 * Daily Pulse Worker — runs once per day to:
 *   1. Update streak (check if studied yesterday).
 *   2. Send motivational reminder if no session today.
 *   3. Clean up stale data.
 */
@HiltWorker
class DailyPulseWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted workerParams: WorkerParameters,
    private val prefs: UserPreferencesRepository,
    private val dao: SankalpDao,
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val now = System.currentTimeMillis()
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        // Check if user studied today
        val todayFocusSec = dao.getTotalFocusSecondsForDay(today, today + 86400000L).first()

        // Update streak
        val currentStreak = prefs.currentStreak.first()
        val lastStudyDate = prefs.lastStudyDate.first()
        val longestStreak = prefs.longestStreak.first()

        val yesterday = today - 86400000L
        val newStreak = if (lastStudyDate != null && lastStudyDate >= yesterday && todayFocusSec > 0) {
            currentStreak + 1
        } else if (lastStudyDate == null || lastStudyDate < yesterday) {
            1 // Reset if missed a day
        } else {
            currentStreak
        }

        val newLongest = maxOf(longestStreak, newStreak)
        prefs.updateStreak(newStreak, newLongest, today)

        // Send reminder if no study session yet today
        if (todayFocusSec == 0L) {
            sendReminderNotification(newStreak)
        }

        return Result.success()
    }

    private fun sendReminderNotification(streak: Int) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val notification = NotificationCompat.Builder(context, "sankalp_reminders")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Sankalp — Your streak is 🔥$streak")
            .setContentText("Don't break the chain. Start your focus session now!")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(DAILY_REMINDER_ID, notification)
    }

    companion object {
        const val DAILY_REMINDER_ID = 2001
        const val WORK_NAME = "daily_pulse"
    }
}
