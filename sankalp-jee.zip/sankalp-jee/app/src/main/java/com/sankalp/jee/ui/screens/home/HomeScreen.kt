package com.sankalp.jee.ui.screens.home

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.domain.usecase.RankEstimator
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToFocus: () -> Unit,
    onNavigateToPlanner: () -> Unit,
    onNavigateToRevision: () -> Unit,
    onNavigateToMusic: () -> Unit,
    onNavigateToSettings: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val themeColors = SankalpTheme.colors

    LaunchedEffect(Unit) {
        // Live background style is available via SankalpTheme.colors.liveBackgroundStyle
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // ─── Greeting Header ───
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text(
                        text = state.greeting,
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    if (state.daysUntilExam != null) {
                        Text(
                            text = "${state.daysUntilExam} days until JEE",
                            style = MaterialTheme.typography.bodyMedium,
                            color = themeColors.themeAccent,
                        )
                    }
                }
                IconButton(onClick = onNavigateToSettings) {
                    Text("⚙", style = MaterialTheme.typography.titleLarge)
                }
            }
        }

        // ─── Hero Metrics Row ───
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                // Streak
                SankalpCard(modifier = Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🔥", style = MaterialTheme.typography.displayMedium)
                        Text(
                            "${state.streak}",
                            style = MaterialTheme.typography.headlineLarge,
                            color = themeColors.streakFlame,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            "Day Streak",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                // Today's Focus
                SankalpCard(modifier = Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⏱", style = MaterialTheme.typography.displayMedium)
                        Text(
                            "${state.todayFocusMin}m",
                            style = MaterialTheme.typography.headlineLarge,
                            color = themeColors.focusActive,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            "Today",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                // Rank
                SankalpCard(modifier = Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎯", style = MaterialTheme.typography.displayMedium)
                        Text(
                            state.estimatedRank?.let { "#$it" } ?: "—",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                        )
                        val trendEmoji = when (state.rankTrend) {
                            RankEstimator.Trend.IMPROVING -> "↑"
                            RankEstimator.Trend.STABLE -> "→"
                            RankEstimator.Trend.DECLINING -> "↓"
                        }
                        Text(
                            "Est. Rank $trendEmoji",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        // ─── Quick Actions ───
        item {
            SectionHeader(title = "Quick Actions")
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    QuickActionChip(
                        emoji = "⏱",
                        label = "Start Focus",
                        color = themeColors.focusActive,
                        onClick = onNavigateToFocus,
                    )
                }
                item {
                    QuickActionChip(
                        emoji = "📋",
                        label = "View Plan",
                        color = MaterialTheme.colorScheme.primary,
                        onClick = onNavigateToPlanner,
                    )
                }
                item {
                    QuickActionChip(
                        emoji = "📚",
                        label = "Revise (${state.dueRevisionCount})",
                        color = themeColors.revisionDue,
                        onClick = onNavigateToRevision,
                    )
                }
                item {
                    QuickActionChip(
                        emoji = "🎵",
                        label = "Study Music",
                        color = themeColors.themeAccent,
                        onClick = onNavigateToMusic,
                    )
                }
            }
        }

        // ─── Today's Progress ───
        item {
            SectionHeader(title = "Today's Progress")
        }

        item {
            SankalpCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(
                            text = "Tasks Completed",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            text = "${state.todayTasksDone} / ${state.todayTasksTotal}",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    val taskProgress = if (state.todayTasksTotal > 0) {
                        state.todayTasksDone.toFloat() / state.todayTasksTotal
                    } else 0f
                    AnimatedRingMeter(
                        progress = taskProgress,
                        color = themeColors.success,
                        size = 80.dp,
                        strokeWidth = 6.dp,
                    )
                }
            }
        }

        // ─── Subject Progress ───
        item {
            SectionHeader(title = "Subject Progress")
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                Subject.values().forEach { subject ->
                    val progress = state.subjectProgress[subject] ?: 0f
                    val color = when (subject) {
                        Subject.PHYSICS -> themeColors.subjectPhysics
                        Subject.CHEMISTRY -> themeColors.subjectChemistry
                        Subject.MATHEMATICS -> themeColors.subjectMaths
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        AnimatedRingMeter(
                            progress = progress,
                            color = color,
                            size = 64.dp,
                            strokeWidth = 5.dp,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = subject.displayName.take(3),
                            style = MaterialTheme.typography.labelMedium,
                            color = color,
                        )
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        // ─── All-Time Stats ───
        item {
            SankalpCard {
                Text(
                    text = "Total Study Time",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = "${state.totalFocusHours}h ${state.totalFocusMinutes % 60}m",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "Longest Streak: ${state.longestStreak} days",
                    style = MaterialTheme.typography.bodyMedium,
                    color = themeColors.streakFlame,
                )
            }
        }

        item { Spacer(Modifier.height(80.dp)) } // Bottom padding for nav bar
    }
}

@Composable
private fun QuickActionChip(
    emoji: String,
    label: String,
    color: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
) {
    ElevatedButton(
        onClick = onClick,
        colors = ButtonDefaults.elevatedButtonColors(
            containerColor = color.copy(alpha = 0.12f),
            contentColor = color,
        ),
        shape = SankalpShapes.xl,
    ) {
        Text(emoji, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.labelLarge)
    }
}
