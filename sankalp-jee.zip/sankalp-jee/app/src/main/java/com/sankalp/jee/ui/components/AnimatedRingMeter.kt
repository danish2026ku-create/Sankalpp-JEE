package com.sankalp.jee.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Animated circular ring meter — used for focus timer, streak, progress.
 *
 * @param progress 0–1 value to display.
 * @param color    Ring colour.
 * @param size     Diameter.
 * @param strokeWidth Ring thickness.
 */
@Composable
fun AnimatedRingMeter(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    strokeWidth: Dp = 8.dp,
    trackColor: Color = color.copy(alpha = 0.15f),
    animate: Boolean = true,
) {
    val animatedProgress by if (animate) {
        animateFloatAsState(
            targetValue = progress.coerceIn(0f, 1f),
            animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioNoBouncy),
            label = "ring_progress",
        )
    } else {
        androidx.compose.runtime.mutableFloatStateOf(progress.coerceIn(0f, 1f))
    }

    Canvas(modifier = modifier.size(size)) {
        val strokePx = strokeWidth.toPx()
        val arcSize = Size(this.size.width - strokePx, this.size.height - strokePx)
        val topLeft = Offset(strokePx / 2f, strokePx / 2f)

        // Track
        drawArc(
            color = trackColor,
            startAngle = -90f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = strokePx, cap = StrokeCap.Round),
        )

        // Progress
        drawArc(
            color = color,
            startAngle = -90f,
            sweepAngle = 360f * animatedProgress,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = strokePx, cap = StrokeCap.Round),
        )
    }
}
