package com.sankalp.jee.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.sankalp.jee.data.local.entities.*

@Database(
    entities = [
        FocusSessionEntity::class,
        StudyTaskEntity::class,
        ChapterEntity::class,
        MockTestEntity::class,
        ErrorEntryEntity::class,
        FlashcardEntity::class,
        NoteEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
@TypeConverters(SankalpTypeConverters::class)
abstract class SankalpDatabase : RoomDatabase() {

    abstract fun dao(): SankalpDao

    companion object {
        const val DATABASE_NAME = "sankalp_database"

        fun create(context: Context): SankalpDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                SankalpDatabase::class.java,
                DATABASE_NAME,
            )
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
