package com.sankalp.jee.ui.theme

import androidx.compose.ui.graphics.Color

// ════════════════════════════════════════════════════════════════
//  Design Token Colours — 10 Themes × (Dark Base + Primary + Accent)
// ════════════════════════════════════════════════════════════════

// Midnight Library
val MidnightBase = Color(0xFF0E1116)
val MidnightPrimary = Color(0xFF7C9CFF)
val MidnightAccent = Color(0xFFE8C49A)
val MidnightOnPrimary = Color(0xFF0A0E18)
val MidnightSurface = Color(0xFF161B24)
val MidnightSurfaceVariant = Color(0xFF1E2430)

// Temple Dawn
val TempleBase = Color(0xFF1A1208)
val TemplePrimary = Color(0xFFFFB347)
val TempleAccent = Color(0xFFFF7043)
val TempleOnPrimary = Color(0xFF1A0E00)
val TempleSurface = Color(0xFF231A0E)
val TempleSurfaceVariant = Color(0xFF2E2214)

// Monsoon Study
val MonsoonBase = Color(0xFF0B1416)
val MonsoonPrimary = Color(0xFF5FD3C4)
val MonsoonAccent = Color(0xFF8AB4F8)
val MonsoonOnPrimary = Color(0xFF041814)
val MonsoonSurface = Color(0xFF121E20)
val MonsoonSurfaceVariant = Color(0xFF18282C)

// Kesar
val KesarBase = Color(0xFF14100A)
val KesarPrimary = Color(0xFFF2B705)
val KesarAccent = Color(0xFFE86A33)
val KesarOnPrimary = Color(0xFF1A1200)
val KesarSurface = Color(0xFF1E180E)
val KesarSurfaceVariant = Color(0xFF282014)

// Neelkanth
val NeelkanthBase = Color(0xFF0A1020)
val NeelkanthPrimary = Color(0xFF4F7CFF)
val NeelkanthAccent = Color(0xFF9B5DE5)
val NeelkanthOnPrimary = Color(0xFF040818)
val NeelkanthSurface = Color(0xFF121A2E)
val NeelkanthSurfaceVariant = Color(0xFF18223C)

// Forest Ashram
val ForestBase = Color(0xFF0C140F)
val ForestPrimary = Color(0xFF5EE0A0)
val ForestAccent = Color(0xFFA3D977)
val ForestOnPrimary = Color(0xFF041A0C)
val ForestSurface = Color(0xFF142018)
val ForestSurfaceVariant = Color(0xFF1C2E20)

// Paper & Ink (Light-first)
val PaperBase = Color(0xFFF4EFE6)
val PaperPrimary = Color(0xFF1F2933)
val PaperAccent = Color(0xFFB23A48)
val PaperOnPrimary = Color(0xFFFFFFFF)
val PaperSurface = Color(0xFFFDFBF7)
val PaperSurfaceVariant = Color(0xFFEDE8DF)

// Aurora Nights
val AuroraBase = Color(0xFF070B14)
val AuroraPrimary = Color(0xFF8B5CF6)
val AuroraAccent = Color(0xFF22D3EE)
val AuroraOnPrimary = Color(0xFF08041A)
val AuroraSurface = Color(0xFF10161E)
val AuroraSurfaceVariant = Color(0xFF182028)

// Copper Dusk
val CopperBase = Color(0xFF170F0B)
val CopperPrimary = Color(0xFFC97B4A)
val CopperAccent = Color(0xFFE0A96D)
val CopperOnPrimary = Color(0xFF1A0E08)
val CopperSurface = Color(0xFF201814)
val CopperSurfaceVariant = Color(0xFF2A201A)

// Emerald Focus
val EmeraldBase = Color(0xFF08130E)
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldAccent = Color(0xFF34D399)
val EmeraldOnPrimary = Color(0xFF041A0E)
val EmeraldSurface = Color(0xFF101E16)
val EmeraldSurfaceVariant = Color(0xFF18281E)

// ════════════════════════════════════════════════════════════════
//  Semantic Colours (shared across themes)
// ════════════════════════════════════════════════════════════════

val FocusActive = Color(0xFF4ADE80)
val FocusIdle = Color(0xFF6B7280)
val StreakFlame = Color(0xFFF97316)
val RevisionDue = Color(0xFFFBBF24)
val Danger = Color(0xFFEF4444)
val Success = Color(0xFF22C55E)
val Warning = Color(0xFFF59E0B)

// Subject Accents
val SubjectPhysics = Color(0xFF60A5FA)
val SubjectChemistry = Color(0xFF34D399)
val SubjectMaths = Color(0xFFF472B6)

// Common
val Transparent = Color.Transparent
val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)
