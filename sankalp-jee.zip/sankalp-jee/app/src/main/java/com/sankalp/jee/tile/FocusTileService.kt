package com.sankalp.jee.tile

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi

/**
 * Quick Settings tile for toggling focus mode.
 * Long-press to open the Focus screen.
 */
@RequiresApi(Build.VERSION_CODES.N)
class FocusTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "Sankalp Focus"
            updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        // Toggle focus mode
        val isActive = qsTile?.state == Tile.STATE_ACTIVE
        qsTile?.apply {
            state = if (isActive) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
            updateTile()
        }
        // In production, launch FocusSessionService with appropriate intent
    }
}
