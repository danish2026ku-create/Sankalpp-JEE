package com.sankalp.jee.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.sankalp.jee.domain.model.ThemeId

/**
 * Extended colour roles beyond Material defaults.
 */
data class SankalpColors(
    val focusActive: Color,
    val focusIdle: Color,
    val streakFlame: Color,
    val revisionDue: Color,
    val danger: Color,
    val success: Color,
    val warning: Color,
    val subjectPhysics: Color,
    val subjectChemistry: Color,
    val subjectMaths: Color,
    val themeAccent: Color,
    val liveBackgroundStyle: LiveBackgroundStyle,
)

enum class LiveBackgroundStyle {
    STARFIELD,
    RISING_GRADIENT,
    RAIN_STREAKS,
    GOLDEN_AURORA,
    BLUE_AURORA,
    LEAF_SHADOW,
    PAPER_GRAIN,
    AURORA_RIBBONS,
    WARM_HAZE,
    EMERALD_PULSE,
    NONE,
}

private val LocalSankalpColors = staticCompositionLocalOf {
    SankalpColors(
        focusActive = FocusActive,
        focusIdle = FocusIdle,
        streakFlame = StreakFlame,
        revisionDue = RevisionDue,
        danger = Danger,
        success = Success,
        warning = Warning,
        subjectPhysics = SubjectPhysics,
        subjectChemistry = SubjectChemistry,
        subjectMaths = SubjectMaths,
        themeAccent = MidnightAccent,
        liveBackgroundStyle = LiveBackgroundStyle.STARFIELD,
    )
}

/**
 * Build the full colour scheme for a given theme.
 */
private fun colorSchemeForTheme(themeId: ThemeId, isDark: Boolean): Pair<androidx.compose.material3.ColorScheme, SankalpColors> {
    val (base, primary, accent, onPrimary, surface, surfaceVariant, bgStyle) = when (themeId) {
        ThemeId.MIDNIGHT_LIBRARY -> MidnightPalette
        ThemeId.TEMPLE_DAWN -> TemplePalette
        ThemeId.MONSOON_STUDY -> MonsoonPalette
        ThemeId.KESAR -> KesarPalette
        ThemeId.NEELKANTH -> NeelkanthPalette
        ThemeId.FOREST_ASHRAM -> ForestPalette
        ThemeId.PAPER_AND_INK -> PaperPalette
        ThemeId.AURORA_NIGHTS -> AuroraPalette
        ThemeId.COPPER_DUSK -> CopperPalette
        ThemeId.EMERALD_FOCUS -> EmeraldPalette
        ThemeId.AUTO -> MidnightPalette // fallback
    }

    val materialColors = if (isDark || themeId != ThemeId.PAPER_AND_INK) {
        darkColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = primary.copy(alpha = 0.2f),
            onPrimaryContainer = primary,
            secondary = accent,
            onSecondary = base,
            tertiary = accent.copy(alpha = 0.7f),
            background = base,
            onBackground = Color.White.copy(alpha = 0.92f),
            surface = surface,
            onSurface = Color.White.copy(alpha = 0.88f),
            surfaceVariant = surfaceVariant,
            onSurfaceVariant = Color.White.copy(alpha = 0.7f),
            outline = Color.White.copy(alpha = 0.15f),
            error = Danger,
            onError = Color.White,
        )
    } else {
        lightColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = primary.copy(alpha = 0.12f),
            onPrimaryContainer = primary,
            secondary = accent,
            onSecondary = Color.White,
            tertiary = accent.copy(alpha = 0.7f),
            background = base,
            onBackground = Color.Black.copy(alpha = 0.87f),
            surface = surface,
            onSurface = Color.Black.copy(alpha = 0.82f),
            surfaceVariant = surfaceVariant,
            onSurfaceVariant = Color.Black.copy(alpha = 0.65f),
            outline = Color.Black.copy(alpha = 0.12f),
            error = Danger,
            onError = Color.White,
        )
    }

    val sankalpColors = SankalpColors(
        focusActive = FocusActive,
        focusIdle = FocusIdle,
        streakFlame = StreakFlame,
        revisionDue = RevisionDue,
        danger = Danger,
        success = Success,
        warning = Warning,
        subjectPhysics = SubjectPhysics,
        subjectChemistry = SubjectChemistry,
        subjectMaths = SubjectMaths,
        themeAccent = accent,
        liveBackgroundStyle = bgStyle,
    )

    return materialColors to sankalpColors
}

// Palette helper: base, primary, accent, onPrimary, surface, surfaceVariant, bgStyle
private data class ThemePalette(
    val base: Color, val primary: Color, val accent: Color,
    val onPrimary: Color, val surface: Color, val surfaceVariant: Color,
    val bgStyle: LiveBackgroundStyle,
)

private val MidnightPalette = ThemePalette(MidnightBase, MidnightPrimary, MidnightAccent, MidnightOnPrimary, MidnightSurface, MidnightSurfaceVariant, LiveBackgroundStyle.STARFIELD)
private val TemplePalette = ThemePalette(TempleBase, TemplePrimary, TempleAccent, TempleOnPrimary, TempleSurface, TempleSurfaceVariant, LiveBackgroundStyle.RISING_GRADIENT)
private val MonsoonPalette = ThemePalette(MonsoonBase, MonsoonPrimary, MonsoonAccent, MonsoonOnPrimary, MonsoonSurface, MonsoonSurfaceVariant, LiveBackgroundStyle.RAIN_STREAKS)
private val KesarPalette = ThemePalette(KesarBase, KesarPrimary, KesarAccent, KesarOnPrimary, KesarSurface, KesarSurfaceVariant, LiveBackgroundStyle.GOLDEN_AURORA)
private val NeelkanthPalette = ThemePalette(NeelkanthBase, NeelkanthPrimary, NeelkanthAccent, NeelkanthOnPrimary, NeelkanthSurface, NeelkanthSurfaceVariant, LiveBackgroundStyle.BLUE_AURORA)
private val ForestPalette = ThemePalette(ForestBase, ForestPrimary, ForestAccent, ForestOnPrimary, ForestSurface, ForestSurfaceVariant, LiveBackgroundStyle.LEAF_SHADOW)
private val PaperPalette = ThemePalette(PaperBase, PaperPrimary, PaperAccent, PaperOnPrimary, PaperSurface, PaperSurfaceVariant, LiveBackgroundStyle.PAPER_GRAIN)
private val AuroraPalette = ThemePalette(AuroraBase, AuroraPrimary, AuroraAccent, AuroraOnPrimary, AuroraSurface, AuroraSurfaceVariant, LiveBackgroundStyle.AURORA_RIBBONS)
private val CopperPalette = ThemePalette(CopperBase, CopperPrimary, CopperAccent, CopperOnPrimary, CopperSurface, CopperSurfaceVariant, LiveBackgroundStyle.WARM_HAZE)
private val EmeraldPalette = ThemePalette(EmeraldBase, EmeraldPrimary, EmeraldAccent, EmeraldOnPrimary, EmeraldSurface, EmeraldSurfaceVariant, LiveBackgroundStyle.EMERALD_PULSE)

/**
 * Sankalp theme — the single entry point for all theming.
 */
@Composable
fun SankalpTheme(
    themeId: ThemeId = ThemeId.MIDNIGHT_LIBRARY,
    content: @Composable () -> Unit,
) {
    val resolvedThemeId = when (themeId) {
        ThemeId.AUTO -> {
            val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
            if (hour < 17) ThemeId.PAPER_AND_INK else ThemeId.MIDNIGHT_LIBRARY
        }
        else -> themeId
    }

    val isDark = resolvedThemeId != ThemeId.PAPER_AND_INK
    val (materialColors, sankalpColors) = colorSchemeForTheme(resolvedThemeId, isDark)

    CompositionLocalProvider(LocalSankalpColors provides sankalpColors) {
        MaterialTheme(
            colorScheme = materialColors,
            typography = SankalpType.toMaterial3Typography(),
            shapes = sankalpMaterial3Shapes(),
            content = content,
        )
    }
}

/** Access Sankalp-specific colours inside any composable. */
object SankalpTheme {
    val colors: SankalpColors
        @Composable
        @ReadOnlyComposable
        get() = LocalSankalpColors.current
}
