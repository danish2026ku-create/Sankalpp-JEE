package com.sankalp.jee.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.CountDownTimer
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.sankalp.jee.MainActivity
import com.sankalp.jee.R
import com.sankalp.jee.data.local.SankalpDao
import com.sankalp.jee.data.local.entities.FocusSessionEntity
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import com.sankalp.jee.domain.model.FocusMode
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/**
 * Foreground service that runs the focus timer countdown.
 *
 * Publishes a persistent notification with remaining time.
 * On completion, logs the session and triggers streak update.
 */
@AndroidEntryPoint
class FocusSessionService : Service() {

    @Inject lateinit var dao: SankalpDao
    @Inject lateinit var prefs: UserPreferencesRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var timer: CountDownTimer? = null

    private var totalDurationMs: Long = 0
    private var remainingMs: Long = 0
    private var startedAt: Long = 0
    private var focusMode: FocusMode = FocusMode.STANDARD
    private var subjectName: String? = null
    private var isPaused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                totalDurationMs = intent.getLongExtra(EXTRA_DURATION_MS, 52 * 60 * 1000L)
                focusMode = intent.getStringExtra(EXTRA_FOCUS_MODE)?.let {
                    runCatching { FocusMode.valueOf(it) }.getOrNull()
                } ?: FocusMode.STANDARD
                subjectName = intent.getStringExtra(EXTRA_SUBJECT)
                startedAt = System.currentTimeMillis()
                remainingMs = totalDurationMs
                startForeground(NOTIFICATION_ID, buildNotification(remainingMs))
                startTimer()
                activateBlocking()
            }
            ACTION_PAUSE -> {
                isPaused = true
                timer?.cancel()
            }
            ACTION_RESUME -> {
                isPaused = false
                startTimer()
            }
            ACTION_STOP -> {
                completeSession()
            }
        }
        return START_STICKY
    }

    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(remainingMs, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                remainingMs = millisUntilFinished
                updateNotification(millisUntilFinished)
            }
            override fun onFinish() {
                completeSession()
            }
        }.start()
    }

    private fun completeSession() {
        timer?.cancel()
        val elapsed = totalDurationMs - remainingMs
        val durationSec = elapsed / 1000

        serviceScope.launch {
            // Log the session
            dao.insertFocusSession(
                FocusSessionEntity(
                    subject = subjectName,
                    durationSec = durationSec,
                    startedAt = startedAt,
                    focusMode = focusMode.name,
                    focusScore = 100,
                )
            )
            // Update streak
            prefs.addFocusMinutes(durationSec / 60)
        }

        deactivateBlocking()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun activateBlocking() {
        serviceScope.launch {
            val blocked = prefs.blockedPackages.first()
            val guardEnabled = prefs.notificationGuard.first()
            SankalpGuardianService.activate(blocked)
            if (guardEnabled) SankalpNotificationGuard.activate()
        }
    }

    private fun deactivateBlocking() {
        SankalpGuardianService.deactivate()
        SankalpNotificationGuard.deactivate()
    }

    private fun buildNotification(remainingMs: Long): Notification {
        val minutes = (remainingMs / 1000) / 60
        val seconds = (remainingMs / 1000) % 60
        val timeText = "%02d:%02d".format(minutes, seconds)

        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Sankalp Focus")
            .setContentText(timeText)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .addAction(R.drawable.ic_launcher_foreground, "Pause",
                PendingIntent.getService(this, 1,
                    Intent(this, FocusSessionService::class.java).apply { action = ACTION_PAUSE },
                    PendingIntent.FLAG_IMMUTABLE))
            .addAction(R.drawable.ic_launcher_foreground, "Stop",
                PendingIntent.getService(this, 2,
                    Intent(this, FocusSessionService::class.java).apply { action = ACTION_STOP },
                    PendingIntent.FLAG_IMMUTABLE))
            .build()
    }

    private fun updateNotification(remainingMs: Long) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification(remainingMs))
    }

    override fun onDestroy() {
        timer?.cancel()
        serviceScope.cancel()
        deactivateBlocking()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "sankalp_focus_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "com.sankalp.jee.action.START_FOCUS"
        const val ACTION_PAUSE = "com.sankalp.jee.action.PAUSE_FOCUS"
        const val ACTION_RESUME = "com.sankalp.jee.action.RESUME_FOCUS"
        const val ACTION_STOP = "com.sankalp.jee.action.STOP_FOCUS"
        const val EXTRA_DURATION_MS = "duration_ms"
        const val EXTRA_FOCUS_MODE = "focus_mode"
        const val EXTRA_SUBJECT = "subject"

        fun createNotificationChannel(context: Context) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Focus Timer",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Shows remaining focus time"
                setSound(null, null)
                enableVibration(false)
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
