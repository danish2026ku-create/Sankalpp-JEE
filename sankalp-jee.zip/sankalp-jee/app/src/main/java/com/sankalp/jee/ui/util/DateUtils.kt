package com.sankalp.jee.ui.util

import java.util.*

/**
 * Date/time utility functions.
 */
object DateUtils {

    fun startOfDay(millis: Long = System.currentTimeMillis()): Long {
        return Calendar.getInstance().apply {
            timeInMillis = millis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun endOfDay(millis: Long = System.currentTimeMillis()): Long {
        return startOfDay(millis) + 86400000L
    }

    fun startOfWeek(): Long {
        return Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    fun daysBetween(start: Long, end: Long): Int {
        val diff = end - start
        return (diff / 86400000L).toInt()
    }

    fun isToday(millis: Long): Boolean {
        val today = startOfDay()
        return millis in today until (today + 86400000L)
    }

    fun isYesterday(millis: Long): Boolean {
        val yesterday = startOfDay() - 86400000L
        return millis in yesterday until (yesterday + 86400000L)
    }

    fun daysUntilExam(examDateMillis: Long): Int {
        val diff = examDateMillis - System.currentTimeMillis()
        return if (diff > 0) (diff / 86400000L).toInt() + 1 else 0
    }
}
