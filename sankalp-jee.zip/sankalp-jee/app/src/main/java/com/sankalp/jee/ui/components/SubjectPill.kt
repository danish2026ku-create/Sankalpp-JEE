package com.sankalp.jee.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.ui.theme.*

/**
 * Small coloured pill indicating a subject.
 */
@Composable
fun SubjectPill(
    subject: Subject,
    modifier: Modifier = Modifier,
) {
    val color = when (subject) {
        Subject.PHYSICS -> SubjectPhysics
        Subject.CHEMISTRY -> SubjectChemistry
        Subject.MATHEMATICS -> SubjectMaths
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 12.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = subject.displayName,
            style = MaterialTheme.typography.labelLarge,
            color = color,
        )
    }
}

@Composable
fun MetricBadge(
    value: String,
    label: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    Column(
        modifier = modifier.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            color = color,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
