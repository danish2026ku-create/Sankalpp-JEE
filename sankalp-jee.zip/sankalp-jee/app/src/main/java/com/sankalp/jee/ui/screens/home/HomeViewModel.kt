package com.sankalp.jee.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sankalp.jee.data.local.SankalpDao
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import com.sankalp.jee.data.prefs.asState
import com.sankalp.jee.domain.model.Chapter
import com.sankalp.jee.domain.model.FocusSession
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.domain.usecase.BuildRevisionQueue
import com.sankalp.jee.domain.usecase.RankEstimator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class HomeUiState(
    val isLoading: Boolean = true,
    val streak: Int = 0,
    val longestStreak: Int = 0,
    val todayFocusMin: Int = 0,
    val totalFocusHours: Long = 0L,
    val daysUntilExam: Int? = null,
    val dueRevisionCount: Int = 0,
    val todayTasksDone: Int = 0,
    val todayTasksTotal: Int = 0,
    val estimatedRank: Int? = null,
    val rankTrend: RankEstimator.Trend = RankEstimator.Trend.STABLE,
    val selectedSubjects: Set<Subject> = emptySet(),
    val greeting: String = "",
    val subjectProgress: Map<Subject, Float> = emptyMap(),
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val dao: SankalpDao,
    private val prefs: UserPreferencesRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                prefs.asState(),
                getTodayFocusMinutes(),
                dao.getAllChapters(),
                dao.getTasksForDay(todayStart(), todayEnd()),
                dao.getAllMockTests(),
                dao.getAllFlashcards(),
            ) { values ->
                @Suppress("UNCHECKED_CAST")
                val prefState = values[0] as com.sankalp.jee.data.prefs.UserPreferencesState
                val todayFocus = values[1] as Long
                val chapters = values[2] as List<com.sankalp.jee.data.local.entities.ChapterEntity>
                val tasks = values[3] as List<com.sankalp.jee.data.local.entities.StudyTaskEntity>
                val mockTests = values[4] as List<com.sankalp.jee.data.local.entities.MockTestEntity>
                val flashcards = values[5] as List<com.sankalp.jee.data.local.entities.FlashcardEntity>

                val domainChapters = chapters.map { it.toDomain() }
                val domainMockTests = mockTests.map { it.toDomain() }
                val domainFlashcards = flashcards.map { it.toDomain() }

                val rankEstimate = RankEstimator.estimate(domainMockTests)
                val revisionCount = BuildRevisionQueue.countDue(
                    domainFlashcards, domainChapters
                )

                // Calculate subject progress
                val subjectProgress = domainChapters
                    .groupBy { it.subject }
                    .mapValues { (_, chaps) ->
                        chaps.map { it.status.progress }.average().toFloat()
                    }

                _state.value.copy(
                    isLoading = false,
                    streak = prefState.currentStreak,
                    longestStreak = prefState.longestStreak,
                    todayFocusMin = todayFocus.toInt(),
                    totalFocusHours = prefState.totalFocusMinutes / 60,
                    daysUntilExam = prefState.daysUntilExam,
                    dueRevisionCount = revisionCount,
                    todayTasksDone = tasks.count { it.isDone },
                    todayTasksTotal = tasks.size,
                    estimatedRank = rankEstimate?.estimatedRank,
                    rankTrend = rankEstimate?.trend ?: RankEstimator.Trend.STABLE,
                    selectedSubjects = prefState.selectedSubjects,
                    greeting = buildGreeting(),
                    subjectProgress = subjectProgress,
                )
            }.collect { _state.value = it }
        }
    }

    private fun buildGreeting(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 5..11 -> "Good Morning 🌅"
            in 12..16 -> "Good Afternoon ☀️"
            in 17..20 -> "Good Evening 🌆"
            else -> "Burning the Midnight Oil 🌙"
        }
    }

    private fun getTodayFocusMinutes(): Flow<Long> {
        return dao.getTotalFocusSecondsForDay(todayStart(), todayEnd())
            .map { it / 60 }
    }

    private fun todayStart(): Long {
        return Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    private fun todayEnd(): Long = todayStart() + 86400000L
}
