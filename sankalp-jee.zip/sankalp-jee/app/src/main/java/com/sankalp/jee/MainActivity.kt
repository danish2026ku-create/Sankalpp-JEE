package com.sankalp.jee

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import com.sankalp.jee.ui.nav.*
import com.sankalp.jee.ui.theme.*
import com.sankalp.jee.domain.model.ThemeId
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

/**
 * Single-activity architecture.
 * All navigation is handled via Compose Navigation.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var prefsRepository: UserPreferencesRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install splash screen
        val splashScreen = installSplashScreen()

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Determine start destination based on onboarding completion
        val isOnboarded = runBlocking { prefsRepository.onboardingComplete.first() }
        val startDest = if (isOnboarded) Routes.HOME else Routes.ONBOARDING

        setContent {
            // Observe theme preference
            var themeId by remember { mutableStateOf(ThemeId.MIDNIGHT_LIBRARY) }
            LaunchedEffect(Unit) {
                prefsRepository.themeId.collect { themeId = it }
            }

            SankalpTheme(themeId = themeId) {
                // Live background behind everything
                LiveBackground(
                    style = SankalpTheme.colors.liveBackgroundStyle,
                    modifier = Modifier.fillMaxSize(),
                )

                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                // Bottom nav routes (hide bottom bar on onboarding and sub-screens)
                val showBottomBar = currentRoute in listOf(
                    Routes.HOME, Routes.FOCUS, Routes.PLANNER, Routes.PRACTICE, Routes.REVISION
                )

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) {
                            SankalpBottomBar(
                                currentRoute = currentRoute,
                                onNavigate = { route ->
                                    navController.navigate(route) {
                                        popUpTo(Routes.HOME) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                            )
                        }
                    },
                ) { innerPadding ->
                    SankalpNavHost(
                        navController = navController,
                        startDestination = startDest,
                        modifier = Modifier.padding(innerPadding),
                    )
                }
            }
        }
    }
}
