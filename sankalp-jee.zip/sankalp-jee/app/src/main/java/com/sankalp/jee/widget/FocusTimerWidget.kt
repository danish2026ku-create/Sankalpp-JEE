package com.sankalp.jee.widget

import android.content.Context
import androidx.glance.*
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.*

/**
 * Focus Timer Widget — shows remaining time and session status.
 */
class FocusTimerWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            FocusTimerWidgetContent()
        }
    }
}

@Composable
private fun FocusTimerWidgetContent() {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .padding(16.dp)
            .background(Color(0xFF0E1116)),
        verticalAlignment = Alignment.CenterVertically,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = "25:00",
            style = TextStyle(
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = ColorProvider(0xFF7C9CFF),
            ),
        )
        Text(
            text = "Focus Session",
            style = TextStyle(
                fontSize = 14.sp,
                color = ColorProvider(0xFFE8C49A),
            ),
        )
        Spacer(modifier = GlanceModifier.height(8.dp))
        Button(
            text = "Start",
            onClick = actionStartActivity<com.sankalp.jee.MainActivity>(),
        )
    }
}

class FocusTimerWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = FocusTimerWidget()
}
