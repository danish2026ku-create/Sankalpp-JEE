package com.sankalp.jee.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sankalp.jee.domain.model.StudyTask
import com.sankalp.jee.domain.model.Subject

@Entity(tableName = "study_tasks")
data class StudyTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: String,
    val chapterId: Long? = null,
    val date: Long,
    val estimatedMin: Int = 45,
    val actualMin: Int? = null,
    val isDone: Boolean = false,
    val priority: Int = 2,
    val createdAt: Long = System.currentTimeMillis(),
) {
    fun toDomain() = StudyTask(
        id = id,
        title = title,
        subject = runCatching { Subject.valueOf(subject) }.getOrDefault(Subject.PHYSICS),
        chapterId = chapterId,
        date = date,
        estimatedMin = estimatedMin,
        actualMin = actualMin,
        isDone = isDone,
        priority = priority,
        createdAt = createdAt,
    )

    companion object {
        fun fromDomain(t: StudyTask) = StudyTaskEntity(
            id = t.id,
            title = t.title,
            subject = t.subject.name,
            chapterId = t.chapterId,
            date = t.date,
            estimatedMin = t.estimatedMin,
            actualMin = t.actualMin,
            isDone = t.isDone,
            priority = t.priority,
            createdAt = t.createdAt,
        )
    }
}
