package com.sankalp.jee.ui.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Haptic feedback utilities.
 */
object Haptics {
    fun tap(context: Context) {
        vibrate(context, durationMs = 20)
    }

    fun success(context: Context) {
        vibrate(context, durationMs = 50)
    }

    fun error(context: Context) {
        vibrate(context, durationMs = 100, amplitude = 255)
    }

    fun celebration(context: Context) {
        val vibrator = getVibrator(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 50, 50, 50, 100), -1)
            )
        }
    }

    private fun vibrate(context: Context, durationMs: Long, amplitude: Int = 128) {
        val vibrator = getVibrator(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
        }
    }

    private fun getVibrator(context: Context): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }
}
