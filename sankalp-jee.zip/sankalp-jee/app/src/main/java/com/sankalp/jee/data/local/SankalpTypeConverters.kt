package com.sankalp.jee.data.local

import androidx.room.TypeConverter

/**
 * Room type converters for enum fields stored as strings.
 * All entities store enums as their `.name` string, so no converter is
 * strictly needed for the current schema — but this class is here as
 * a hook for any future complex types (List<Long>, JSON blobs, etc.).
 */
class SankalpTypeConverters {

    @TypeConverter
    fun fromLongList(value: List<Long>?): String? =
        value?.joinToString(",")

    @TypeConverter
    fun toLongList(value: String?): List<Long>? =
        value?.split(",")?.mapNotNull { it.toLongOrNull() }

    @TypeConverter
    fun fromStringList(value: List<String>?): String? =
        value?.joinToString("|")

    @TypeConverter
    fun toStringList(value: String?): List<String>? =
        value?.split("|")
}
