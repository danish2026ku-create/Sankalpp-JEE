package com.sankalp.jee.ui.screens.focus

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sankalp.jee.data.local.SankalpDao
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import com.sankalp.jee.domain.model.FocusMode
import com.sankalp.jee.domain.model.Subject
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class FocusUiState(
    val isLoading: Boolean = true,
    val isFocusActive: Boolean = false,
    val remainingSeconds: Long = 0,
    val totalSeconds: Long = 0,
    val focusMode: FocusMode = FocusMode.STANDARD,
    val focusDurationMin: Int = 52,
    val selectedSubject: Subject? = null,
    val todayFocusMin: Int = 0,
    val sessionsToday: Int = 0,
    val blockedAppCount: Int = 0,
    val isStrictMode: Boolean = false,
    val isNotificationGuard: Boolean = false,
    val autoFocusEnabled: Boolean = false,
    val autoFocusStartHour: Int = 6,
    val autoFocusEndHour: Int = 22,
)

@HiltViewModel
class FocusViewModel @Inject constructor(
    private val dao: SankalpDao,
    private val prefs: UserPreferencesRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(FocusUiState())
    val state: StateFlow<FocusUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            prefs.asState().collect { prefState ->
                _state.value = _state.value.copy(
                    isLoading = false,
                    focusMode = prefState.focusMode,
                    focusDurationMin = prefState.focusDurationMin,
                    isStrictMode = prefState.strictMode,
                    isNotificationGuard = prefState.notificationGuard,
                    blockedAppCount = prefState.blockedPackages.size,
                    autoFocusEnabled = prefState.autoFocusEnabled,
                    autoFocusStartHour = prefState.autoFocusStartHour,
                    autoFocusEndHour = prefState.autoFocusEndHour,
                )
            }
        }

        viewModelScope.launch {
            val today = todayStart()
            dao.getTotalFocusSecondsForDay(today, today + 86400000L).collect { seconds ->
                _state.value = _state.value.copy(todayFocusMin = (seconds / 60).toInt())
            }
        }

        viewModelScope.launch {
            val today = todayStart()
            dao.getFocusSessionsForDay(today, today + 86400000L).collect { sessions ->
                _state.value = _state.value.copy(sessionsToday = sessions.size)
            }
        }
    }

    fun setFocusDuration(minutes: Int) {
        _state.value = _state.value.copy(focusDurationMin = minutes)
        viewModelScope.launch { prefs.setFocusDurationMin(minutes) }
    }

    fun setFocusMode(mode: FocusMode) {
        _state.value = _state.value.copy(focusMode = mode)
        viewModelScope.launch { prefs.setFocusMode(mode) }
    }

    fun setSelectedSubject(subject: Subject?) {
        _state.value = _state.value.copy(selectedSubject = subject)
    }

    fun startFocus() {
        _state.value = _state.value.copy(
            isFocusActive = true,
            totalSeconds = _state.value.focusDurationMin * 60L,
            remainingSeconds = _state.value.focusDurationMin * 60L,
        )
    }

    fun tickOneSecond() {
        val current = _state.value.remainingSeconds
        if (current > 0) {
            _state.value = _state.value.copy(remainingSeconds = current - 1)
        } else {
            completeFocus()
        }
    }

    fun pauseFocus() {
        _state.value = _state.value.copy(isFocusActive = false)
    }

    fun resumeFocus() {
        _state.value = _state.value.copy(isFocusActive = true)
    }

    private fun completeFocus() {
        val totalSec = _state.value.totalSeconds
        viewModelScope.launch {
            prefs.addFocusMinutes(totalSec / 60)
        }
        _state.value = _state.value.copy(
            isFocusActive = false,
            remainingSeconds = 0,
        )
    }

    fun stopFocus() {
        _state.value = _state.value.copy(
            isFocusActive = false,
            remainingSeconds = 0,
        )
    }

    fun setStrictMode(enabled: Boolean) {
        _state.value = _state.value.copy(isStrictMode = enabled)
        viewModelScope.launch { prefs.setStrictMode(enabled) }
    }

    fun setNotificationGuard(enabled: Boolean) {
        _state.value = _state.value.copy(isNotificationGuard = enabled)
        viewModelScope.launch { prefs.setNotificationGuard(enabled) }
    }

    private fun todayStart(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
