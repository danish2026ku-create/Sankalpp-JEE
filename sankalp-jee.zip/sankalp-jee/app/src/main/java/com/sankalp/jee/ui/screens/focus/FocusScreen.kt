package com.sankalp.jee.ui.screens.focus

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sankalp.jee.domain.model.FocusMode
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusScreen(
    onNavigateToBlockedApps: () -> Unit,
    onNavigateToNotificationGuard: () -> Unit,
    onNavigateToSchedule: () -> Unit,
    viewModel: FocusViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsState()
    val themeColors = SankalpTheme.colors

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // ─── Title ───
        Text(
            text = "Focus",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.align(Alignment.Start),
        )
        Spacer(Modifier.height(24.dp))

        // ─── Timer Ring ───
        Box(contentAlignment = Alignment.Center) {
            val progress = if (state.totalSeconds > 0) {
                state.remainingSeconds.toFloat() / state.totalSeconds
            } else 0f

            AnimatedRingMeter(
                progress = progress,
                color = if (state.isFocusActive) themeColors.focusActive else themeColors.focusIdle,
                size = 280.dp,
                strokeWidth = 12.dp,
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Timer display
                val minutes = state.remainingSeconds / 60
                val seconds = state.remainingSeconds % 60
                Text(
                    text = "%02d:%02d".format(minutes, seconds),
                    style = SankalpType.timerDisplay,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Light,
                )

                if (!state.isFocusActive && state.remainingSeconds == 0L) {
                    Text(
                        text = "Ready",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else if (state.isFocusActive) {
                    Text(
                        text = "Focusing…",
                        style = MaterialTheme.typography.titleMedium,
                        color = themeColors.focusActive,
                    )
                } else {
                    Text(
                        text = "Paused",
                        style = MaterialTheme.typography.titleMedium,
                        color = themeColors.warning,
                    )
                }
            }
        }

        Spacer(Modifier.height(32.dp))

        // ─── Control Buttons ───
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (!state.isFocusActive && state.remainingSeconds == 0L) {
                // Start button
                Button(
                    onClick = { viewModel.startFocus() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = themeColors.focusActive,
                    ),
                    shape = SankalpShapes.full,
                    modifier = Modifier.sizeIn(minWidth = 160.dp),
                ) {
                    Text("Start Focus", style = MaterialTheme.typography.titleMedium)
                }
            } else if (state.isFocusActive) {
                // Pause
                OutlinedButton(
                    onClick = { viewModel.pauseFocus() },
                    shape = SankalpShapes.full,
                ) {
                    Text("Pause")
                }
                // Stop
                Button(
                    onClick = { viewModel.stopFocus() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = themeColors.danger,
                    ),
                    shape = SankalpShapes.full,
                ) {
                    Text("Stop")
                }
            } else {
                // Resume
                Button(
                    onClick = { viewModel.resumeFocus() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = themeColors.focusActive,
                    ),
                    shape = SankalpShapes.full,
                ) {
                    Text("Resume")
                }
                // Stop
                OutlinedButton(
                    onClick = { viewModel.stopFocus() },
                    shape = SankalpShapes.full,
                ) {
                    Text("End")
                }
            }
        }

        Spacer(Modifier.height(32.dp))

        // ─── Duration Selector ───
        if (!state.isFocusActive) {
            SectionHeader(title = "Duration")
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(25, 35, 52, 60, 90).forEach { mins ->
                    item {
                        FilterChip(
                            selected = state.focusDurationMin == mins,
                            onClick = { viewModel.setFocusDuration(mins) },
                            label = { Text("${mins}m") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary,
                            ),
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ─── Subject Tag ───
        if (!state.isFocusActive) {
            SectionHeader(title = "Subject (Optional)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Subject.values().forEach { subject ->
                    SubjectPill(subject = subject)
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // ─── Focus Mode ───
        if (!state.isFocusActive) {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Focus Mode",
                    style = MaterialTheme.typography.titleMedium,
                )
                Spacer(Modifier.height(12.dp))
                FocusMode.values().forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mode.displayName,
                                style = MaterialTheme.typography.bodyLarge,
                            )
                            Text(
                                text = mode.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        RadioButton(
                            selected = state.focusMode == mode,
                            onClick = { viewModel.setFocusMode(mode) },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = MaterialTheme.colorScheme.primary,
                            ),
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ─── Settings Links ───
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            TextButton(onClick = onNavigateToBlockedApps) {
                Text("Blocked Apps (${state.blockedAppCount})")
            }
            TextButton(onClick = onNavigateToNotificationGuard) {
                Text("Notification Guard")
            }
            TextButton(onClick = onNavigateToSchedule) {
                Text("Schedule")
            }
        }

        Spacer(Modifier.height(16.dp))

        // ─── Today Stats ───
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            MetricBadge(
                value = "${state.todayFocusMin}m",
                label = "Today",
                color = themeColors.focusActive,
            )
            MetricBadge(
                value = "${state.sessionsToday}",
                label = "Sessions",
                color = MaterialTheme.colorScheme.primary,
            )
            MetricBadge(
                value = state.focusMode.displayName,
                label = "Mode",
                color = themeColors.themeAccent,
            )
        }

        Spacer(Modifier.height(80.dp))
    }
}

// ─── Sub-screens (stubs with full structure) ───

@Composable
fun BlockedAppsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Blocked Apps") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("←") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
        ) {
            Text(
                text = "Select apps to block during focus sessions",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            EmptyState(
                emoji = "📱",
                message = "Select apps from your installed list to block them during focus sessions.",
            )
        }
    }
}

@Composable
fun NotificationGuardScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notification Guard") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("←") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
        ) {
            Text(
                text = "Silence distracting notifications during focus",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(16.dp))
            EmptyState(
                emoji = "🔕",
                message = "Grant notification access to silence non-essential notifications during focus.",
            )
        }
    }
}

@Composable
fun ScheduleScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Focus Schedule") },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("←") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
        ) {
            Text(
                text = "Auto-start and auto-end focus at set times",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun StrictModeDialog(onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enable Strict Mode?") },
        text = {
            Text("Once activated, you cannot exit this focus session until the timer ends. Are you sure?")
        },
        confirmButton = {
            Button(onClick = onConfirm) { Text("Activate") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
