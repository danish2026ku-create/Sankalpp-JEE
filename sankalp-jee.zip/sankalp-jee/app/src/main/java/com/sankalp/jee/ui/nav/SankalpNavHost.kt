package com.sankalp.jee.ui.nav

import androidx.compose.animation.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.sankalp.jee.ui.screens.focus.*
import com.sankalp.jee.ui.screens.home.*
import com.sankalp.jee.ui.screens.music.*
import com.sankalp.jee.ui.screens.onboarding.*
import com.sankalp.jee.ui.screens.planner.*
import com.sankalp.jee.ui.screens.practice.*
import com.sankalp.jee.ui.screens.revision.*
import com.sankalp.jee.ui.screens.settings.*

/**
 * Main navigation host for Sankalp — all routes defined here.
 */
@Composable
fun SankalpNavHost(
    navController: NavHostController,
    startDestination: String,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier,
        enterTransition = { fadeIn(animationSpec = tween(250)) },
        exitTransition = { fadeOut(animationSpec = tween(150)) },
        popEnterTransition = { fadeIn(animationSpec = tween(200)) },
        popExitTransition = { fadeOut(animationSpec = tween(200)) },
    ) {
        // ─── Onboarding ───
        composable(Routes.ONBOARDING) {
            OnboardingFlow(
                onComplete = {
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.ONBOARDING) { inclusive = true }
                    }
                },
            )
        }

        // ─── Home ───
        composable(Routes.HOME) {
            HomeScreen(
                onNavigateToFocus = { navController.navigate(Routes.FOCUS) },
                onNavigateToPlanner = { navController.navigate(Routes.PLANNER) },
                onNavigateToRevision = { navController.navigate(Routes.REVISION) },
                onNavigateToMusic = { navController.navigate(Routes.MUSIC) },
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) },
            )
        }

        // ─── Focus Timer ───
        composable(Routes.FOCUS) {
            FocusScreen(
                onNavigateToBlockedApps = { navController.navigate(Routes.BLOCKED_APPS) },
                onNavigateToNotificationGuard = { navController.navigate(Routes.NOTIFICATION_GUARD) },
                onNavigateToSchedule = { navController.navigate(Routes.FOCUS_SCHEDULE) },
            )
        }

        composable(Routes.BLOCKED_APPS) {
            BlockedAppsScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.NOTIFICATION_GUARD) {
            NotificationGuardScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.FOCUS_SCHEDULE) {
            ScheduleScreen(onBack = { navController.popBackStack() })
        }

        // ─── Music ───
        composable(Routes.MUSIC) {
            MusicScreen(
                onNavigateToSoundscapes = { navController.navigate(Routes.SOUNDSCAPES) },
                onBack = { navController.popBackStack() },
            )
        }

        composable(Routes.SOUNDSCAPES) {
            SoundscapesScreen(onBack = { navController.popBackStack() })
        }

        // ─── Planner ───
        composable(Routes.PLANNER) {
            PlannerScreen(
                onNavigateToSyllabus = { navController.navigate(Routes.SYLLABUS) },
                onNavigateToBacklog = { navController.navigate(Routes.BACKLOG) },
            )
        }

        composable(Routes.SYLLABUS) {
            SyllabusScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.BACKLOG) {
            BacklogScreen(onBack = { navController.popBackStack() })
        }

        // ─── Practice ───
        composable(Routes.PRACTICE) {
            PracticeScreen(
                onNavigateToMockLog = { navController.navigate(Routes.MOCK_LOG) },
                onNavigateToErrorBook = { navController.navigate(Routes.ERROR_BOOK) },
                onNavigateToWeaknessRadar = { navController.navigate(Routes.WEAKNESS_RADAR) },
            )
        }

        composable(Routes.MOCK_LOG) {
            MockLogScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.ERROR_BOOK) {
            ErrorBookScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.WEAKNESS_RADAR) {
            WeaknessRadarScreen(onBack = { navController.popBackStack() })
        }

        // ─── Revision ───
        composable(Routes.REVISION) {
            RevisionScreen(
                onNavigateToFormulaVault = { navController.navigate(Routes.FORMULA_VAULT) },
                onNavigateToNotes = { navController.navigate(Routes.NOTES) },
            )
        }

        composable(Routes.FORMULA_VAULT) {
            FormulaVaultScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.NOTES) {
            NotesScreen(onBack = { navController.popBackStack() })
        }

        // ─── Settings ───
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onNavigateToThemePicker = { navController.navigate(Routes.THEME_PICKER) },
                onNavigateToBackup = { navController.navigate(Routes.BACKUP) },
                onBack = { navController.popBackStack() },
            )
        }

        composable(Routes.THEME_PICKER) {
            ThemePickerScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.BACKUP) {
            BackupScreen(onBack = { navController.popBackStack() })
        }
    }
}
