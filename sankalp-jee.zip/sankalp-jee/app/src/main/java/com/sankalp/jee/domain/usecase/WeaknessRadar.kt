package com.sankalp.jee.domain.usecase

import com.sankalp.jee.domain.model.Chapter
import com.sankalp.jee.domain.model.ErrorCategory
import com.sankalp.jee.domain.model.ErrorEntry
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.domain.model.TopicStatus
import com.sankalp.jee.domain.model.WeightageTier

/**
 * Weakness Radar — identifies the chapters where a student is weakest.
 *
 * Combines three signals:
 *   1. Error frequency (from Error Book).
 *   2. Low mastery status (from Syllabus Tracker).
 *   3. High weightage (chapters worth more marks).
 *
 * Output: a ranked list of WeaknessScore per chapter, highest first.
 */
object WeaknessRadar {

    data class WeaknessScore(
        val chapter: Chapter,
        val score: Float,          // 0–100, higher = weaker
        val errorCount: Int,
        val masteryGap: Float,     // 1 - status.progress (0 = mastered, 1 = not started)
        val weightBonus: Float,    // multiplier from weightage tier
    )

    /**
     * Compute weakness scores across all chapters.
     *
     * @param chapters All chapters in the syllabus.
     * @param errors   All entries in the Error Book.
     * @return List sorted by weakness score descending (weakest first).
     */
    fun compute(
        chapters: List<Chapter>,
        errors: List<ErrorEntry>,
    ): List<WeaknessScore> {
        // Count unresolved errors per chapter
        val errorCounts = errors
            .filter { !it.isResolved }
            .groupingBy { it.chapterId }
            .eachCount()

        return chapters.map { chapter ->
            val errorsForChapter = errorCounts[chapter.id] ?: 0
            val masteryGap = 1f - chapter.status.progress
            val weightBonus = chapter.weightage.weight.toFloat() / 3f

            // Composite score: weighted combination
            // 40% errors, 35% mastery gap, 25% weightage importance
            val errorScore = (errorsForChapter.coerceAtMost(10) / 10f) * 100f
            val masteryScore = masteryGap * 100f
            val weightScore = weightBonus * 100f

            val composite = errorScore * 0.40f + masteryScore * 0.35f + weightScore * 0.25f

            WeaknessScore(
                chapter = chapter,
                score = composite.coerceIn(0f, 100f),
                errorCount = errorsForChapter,
                masteryGap = masteryGap,
                weightBonus = weightBonus,
            )
        }.sortedByDescending { it.score }
    }

    /**
     * Get the top N weakest chapters overall.
     */
    fun topWeaknesses(
        chapters: List<Chapter>,
        errors: List<ErrorEntry>,
        n: Int = 5,
    ): List<WeaknessScore> = compute(chapters, errors).take(n)

    /**
     * Get the top N weakest chapters for a specific subject.
     */
    fun topWeaknessesForSubject(
        chapters: List<Chapter>,
        errors: List<ErrorEntry>,
        subject: Subject,
        n: Int = 5,
    ): List<WeaknessScore> = compute(chapters, errors)
        .filter { it.chapter.subject == subject }
        .take(n)

    /**
     * Categorize errors to find patterns.
     */
    fun errorPatterns(errors: List<ErrorEntry>): Map<ErrorCategory, Int> =
        errors.filter { !it.isResolved }
            .groupingBy { it.category }
            .eachCount()
}
