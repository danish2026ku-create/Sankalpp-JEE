package com.sankalp.jee.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalDensity

/**
 * Motion tokens — durations, easings, and springs.
 */
object SankalpMotion {
    // Durations
    const val INSTANT = 100
    const val FAST = 150
    const val MEDIUM = 250
    const val SLOW = 400
    const val XSLOW = 600

    // Easings
    val StandardEasing = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    val EmphasizedEasing = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
    val DecelerateEasing = CubicBezierEasing(0f, 0f, 0f, 1f)

    // Springs
    val BouncySpring = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy)
    val GentleSpring = spring(stiffness = 220f, dampingRatio = 0.7f)
}

/**
 * Check if reduced motion is enabled system-wide.
 */
@Composable
fun isReducedMotion(): Boolean {
    // In production, check Settings.Global.ANIMATOR_DURATION_SCALE
    return false
}
