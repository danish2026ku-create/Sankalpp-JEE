package com.sankalp.jee.ui.theme

import androidx.compose.ui.unit.dp

/**
 * Spacing tokens on a 4/8pt grid.
 */
object SankalpSpacing {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
    val xxxl = 48.dp
}
