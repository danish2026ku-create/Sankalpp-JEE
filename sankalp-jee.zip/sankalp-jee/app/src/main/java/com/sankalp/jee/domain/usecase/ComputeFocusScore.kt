package com.sankalp.jee.domain.usecase

import com.sankalp.jee.domain.model.FocusMode
import com.sankalp.jee.domain.model.FocusSession

/**
 * Computes a quality score (0–100) for a focus session.
 *
 * Factors:
 *   1. Duration adherence (did they complete the planned time?).
 *   2. Interruptions (app switches, notifications blocked).
 *   3. Focus mode strictness (stricter mode = higher baseline score).
 *   4. Time of day bonus (early morning / late night sessions get a small boost).
 */
object ComputeFocusScore {

    data class FocusMetrics(
        val plannedDurationSec: Long,
        val actualDurationSec: Long,
        val interruptions: Int,     // App switches or notification attempts
        val focusMode: FocusMode,
        val hourOfDay: Int,         // 0–23 when session started
    )

    /**
     * Compute a focus score for a completed session.
     *
     * @return Score 0–100.
     */
    fun compute(metrics: FocusMetrics): Int {
        // 1. Duration adherence (0–40 points)
        val adherenceRatio = if (metrics.plannedDurationSec > 0) {
            (metrics.actualDurationSec.toFloat() / metrics.plannedDurationSec).coerceIn(0f, 1.5f)
        } else 1f
        val adherenceScore = (adherenceRatio.coerceAtMost(1f) * 40f).toInt()

        // 2. Interruption penalty (0–30 points, fewer = better)
        val interruptionScore = when {
            metrics.interruptions == 0 -> 30
            metrics.interruptions <= 2 -> 25
            metrics.interruptions <= 5 -> 18
            metrics.interruptions <= 10 -> 10
            else -> 0
        }

        // 3. Mode bonus (0–20 points, stricter = more credit)
        val modeScore = when (metrics.focusMode) {
            FocusMode.LOCKDOWN -> 20
            FocusMode.STRICT -> 15
            FocusMode.STANDARD -> 10
            FocusMode.GENTLE -> 5
        }

        // 4. Time-of-day bonus (0–10 points)
        val timeScore = when (metrics.hourOfDay) {
            in 5..7 -> 10     // Early morning warrior
            in 8..11 -> 8     // Morning session
            in 12..14 -> 5    // Afternoon
            in 15..17 -> 6    // Late afternoon
            in 18..21 -> 7    // Evening
            in 22..23 -> 8    // Late night studier
            else -> 3         // Midnight / very early
        }

        return (adherenceScore + interruptionScore + modeScore + timeScore).coerceIn(0, 100)
    }

    /**
     * Compute score from a completed FocusSession domain model.
     */
    fun fromSession(
        session: FocusSession,
        plannedDurationSec: Long,
        interruptions: Int,
    ): Int = compute(
        FocusMetrics(
            plannedDurationSec = plannedDurationSec,
            actualDurationSec = session.durationSec,
            interruptions = interruptions,
            focusMode = session.focusMode,
            hourOfDay = java.util.Calendar.getInstance().apply {
                timeInMillis = session.startedAt
            }.get(java.util.Calendar.HOUR_OF_DAY),
        )
    )

    /**
     * Get a human-readable focus quality label.
     */
    fun qualityLabel(score: Int): String = when {
        score >= 90 -> "Legendary"
        score >= 75 -> "Excellent"
        score >= 60 -> "Good"
        score >= 40 -> "Fair"
        else -> "Needs Improvement"
    }
}
