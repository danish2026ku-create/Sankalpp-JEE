package com.sankalp.jee.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sankalp.jee.domain.model.FocusMode
import com.sankalp.jee.domain.model.Subject

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String? = null,          // Subject name or null
    val chapterId: Long? = null,
    val durationSec: Long,
    val startedAt: Long,
    val focusMode: String = FocusMode.GENTLE.name,
    val focusScore: Int = 100,
    val interruptions: Int = 0,
) {
    fun toDomain() = com.sankalp.jee.domain.model.FocusSession(
        id = id,
        subject = subject?.let { runCatching { Subject.valueOf(it) }.getOrNull() },
        chapterId = chapterId,
        durationSec = durationSec,
        startedAt = startedAt,
        focusMode = runCatching { FocusMode.valueOf(focusMode) }.getOrDefault(FocusMode.GENTLE),
        focusScore = focusScore,
    )

    companion object {
        fun fromDomain(s: com.sankalp.jee.domain.model.FocusSession, interruptions: Int = 0) =
            FocusSessionEntity(
                id = s.id,
                subject = s.subject?.name,
                chapterId = s.chapterId,
                durationSec = s.durationSec,
                startedAt = s.startedAt,
                focusMode = s.focusMode.name,
                focusScore = s.focusScore,
                interruptions = interruptions,
            )
    }
}
