package com.sankalp.jee.data.music

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Repository managing music / soundscape playback state.
 * Wraps ExoPlayer for actual playback; exposes state via StateFlow.
 */
@Singleton
class MusicRepository @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    data class PlaybackState(
        val isPlaying: Boolean = false,
        val currentSoundscape: Soundscape? = null,
        val volume: Float = 0.5f,
        val progress: Float = 0f,      // 0–1
        val isLooping: Boolean = true,
    )

    private val _state = MutableStateFlow(PlaybackState())
    val state: StateFlow<PlaybackState> = _state.asStateFlow()

    fun play(soundscape: Soundscape) {
        _state.value = _state.value.copy(
            isPlaying = true,
            currentSoundscape = soundscape,
            progress = 0f,
        )
        // Actual ExoPlayer setup would happen here in Phase 6
    }

    fun pause() {
        _state.value = _state.value.copy(isPlaying = false)
    }

    fun resume() {
        _state.value = _state.value.copy(isPlaying = true)
    }

    fun stop() {
        _state.value = PlaybackState()
    }

    fun setVolume(volume: Float) {
        _state.value = _state.value.copy(volume = volume.coerceIn(0f, 1f))
    }

    fun updateProgress(progress: Float) {
        _state.value = _state.value.copy(progress = progress.coerceIn(0f, 1f))
    }

    fun toggleLoop() {
        _state.value = _state.value.copy(isLooping = !_state.value.isLooping)
    }
}
