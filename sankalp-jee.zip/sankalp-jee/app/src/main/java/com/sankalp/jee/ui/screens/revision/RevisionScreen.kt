package com.sankalp.jee.ui.screens.revision

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.SankalpTheme

@Composable
fun RevisionScreen(
    onNavigateToFormulaVault: () -> Unit,
    onNavigateToNotes: () -> Unit,
) {
    val themeColors = SankalpTheme.colors

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Text("Revision", style = MaterialTheme.typography.headlineLarge)
        }

        // Due today card
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("📅", style = MaterialTheme.typography.displayMedium)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Due Today", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("No flashcards due — start creating some!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Flashcards
        item {
            SectionHeader(title = "Flashcards (SM-2)")
        }
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Text("🧠 Start Revision Session", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text("Review due flashcards using the SM-2 spaced repetition algorithm",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { /* Start revision */ }) { Text("Begin") }
            }
        }

        // Formula Vault
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("🔬 Formula Vault", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Quick access to all your saved formulas",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onNavigateToFormulaVault) { Text("View →") }
                }
            }
        }

        // Notes
        item {
            SankalpCard(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("📝 Quick Notes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Your study notes and shortcuts",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onNavigateToNotes) { Text("View →") }
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
fun FormulaVaultScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Formula Vault") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            EmptyState(emoji = "🔬", message = "Save your important formulas here for quick revision")
        }
    }
}

@Composable
fun NotesScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Quick Notes") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } }) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            EmptyState(emoji = "📝", message = "Create quick notes for revision")
        }
    }
}
