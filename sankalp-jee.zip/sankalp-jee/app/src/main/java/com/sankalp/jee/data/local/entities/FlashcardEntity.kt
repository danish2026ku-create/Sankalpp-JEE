package com.sankalp.jee.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sankalp.jee.domain.model.Flashcard
import com.sankalp.jee.domain.model.Subject

@Entity(tableName = "flashcards")
data class FlashcardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: String,
    val chapterId: Long? = null,
    val front: String,
    val back: String,
    val easeFactor: Float = 2.5f,
    val interval: Int = 0,
    val repetitions: Int = 0,
    val nextReview: Long = System.currentTimeMillis(),
    val lastReview: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
) {
    fun toDomain() = Flashcard(
        id = id,
        subject = runCatching { Subject.valueOf(subject) }.getOrDefault(Subject.PHYSICS),
        chapterId = chapterId,
        front = front, back = back,
        easeFactor = easeFactor, interval = interval,
        repetitions = repetitions, nextReview = nextReview,
        lastReview = lastReview, createdAt = createdAt,
    )

    companion object {
        fun fromDomain(f: Flashcard) = FlashcardEntity(
            id = f.id, subject = f.subject.name, chapterId = f.chapterId,
            front = f.front, back = f.back,
            easeFactor = f.easeFactor, interval = f.interval,
            repetitions = f.repetitions, nextReview = f.nextReview,
            lastReview = f.lastReview, createdAt = f.createdAt,
        )
    }
}
