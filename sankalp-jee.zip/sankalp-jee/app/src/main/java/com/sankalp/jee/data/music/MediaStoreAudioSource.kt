package com.sankalp.jee.data.music

import android.content.Context
import android.provider.MediaStore
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Reads user's own audio files from MediaStore (for custom study music).
 * Only used if the user wants to use their own audio instead of bundled soundscapes.
 */
@Singleton
class MediaStoreAudioSource @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    data class AudioFile(
        val id: Long,
        val title: String,
        val artist: String?,
        val durationMs: Long,
        val uri: String,
    )

    /**
     * Query audio files from MediaStore.
     * Returns empty list if permission is not granted.
     */
    fun queryAudioFiles(): List<AudioFile> {
        return try {
            val audioFiles = mutableListOf<AudioFile>()
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DURATION,
            )
            val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, sortOrder,
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol)
                    val artist = cursor.getString(artistCol)
                    val duration = cursor.getLong(durationCol)
                    audioFiles.add(
                        AudioFile(
                            id = id,
                            title = title,
                            artist = artist,
                            durationMs = duration,
                            uri = android.content.ContentUris.withAppendedId(
                                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id
                            ).toString(),
                        )
                    )
                }
            }
            audioFiles
        } catch (e: SecurityException) {
            emptyList()
        }
    }
}
