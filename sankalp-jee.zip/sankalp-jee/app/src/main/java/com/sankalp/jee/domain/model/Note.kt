package com.sankalp.jee.domain.model

/**
 * A quick note or formula saved by the student.
 *
 * @property id        Unique row ID.
 * @property title     Note title or formula name.
 * @property content   Full content (supports markdown-style text).
 * @property subject   Optional linked subject.
 * @property chapterId Optional linked chapter.
 * @property isFormula Whether this is a formula (shows in Formula Vault).
 * @property createdAt Epoch millis when created.
 * @property updatedAt Epoch millis when last modified.
 */
data class Note(
    val id: Long = 0,
    val title: String,
    val content: String,
    val subject: Subject? = null,
    val chapterId: Long? = null,
    val isFormula: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)
