package com.sankalp.jee.domain.model

/**
 * Weightage tier for a chapter — how heavily it's tested in JEE.
 */
enum class WeightageTier(val displayName: String, val weight: Int) {
    HIGH("High Weightage", 3),
    MEDIUM("Medium Weightage", 2),
    LOW("Low Weightage", 1);
}
