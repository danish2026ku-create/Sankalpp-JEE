package com.sankalp.jee.service.work

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.util.Calendar

/**
 * Streak Guard Worker — runs at end of day to check if the user
 * studied today. If not, the streak resets (with grace for late-night sessions).
 */
@HiltWorker
class StreakGuardWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted workerParams: WorkerParameters,
    private val prefs: UserPreferencesRepository,
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val now = System.currentTimeMillis()
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val lastStudyDate = prefs.lastStudyDate.first()
        val currentStreak = prefs.currentStreak.first()

        // If the last study date is before yesterday, streak is broken
        val yesterday = today - 86400000L
        if (lastStudyDate == null || lastStudyDate < yesterday) {
            // Streak broken — reset to 0
            prefs.updateStreak(0, prefs.longestStreak.first(), lastStudyDate ?: 0)
        }

        return Result.success()
    }

    companion object {
        const val WORK_NAME = "streak_guard"
    }
}
