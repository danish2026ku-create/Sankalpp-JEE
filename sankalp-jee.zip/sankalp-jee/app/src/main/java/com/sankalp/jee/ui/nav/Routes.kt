package com.sankalp.jee.ui.nav

/**
 * All navigation routes in the Sankalp app.
 */
object Routes {
    // Onboarding
    const val ONBOARDING = "onboarding"

    // Main destinations (bottom nav)
    const val HOME = "home"
    const val FOCUS = "focus"
    const val PLANNER = "planner"
    const val PRACTICE = "practice"
    const val REVISION = "revision"

    // Focus sub-screens
    const val BLOCKED_APPS = "blocked_apps"
    const val NOTIFICATION_GUARD = "notification_guard"
    const val FOCUS_SCHEDULE = "focus_schedule"
    const val STRICT_MODE_DIALOG = "strict_mode_dialog"

    // Planner sub-screens
    const val SYLLABUS = "syllabus"
    const val BACKLOG = "backlog"

    // Practice sub-screens
    const val MOCK_LOG = "mock_log"
    const val ERROR_BOOK = "error_book"
    const val WEAKNESS_RADAR = "weakness_radar"

    // Revision sub-screens
    const val FORMULA_VAULT = "formula_vault"
    const val NOTES = "notes"

    // Music
    const val MUSIC = "music"
    const val SOUNDSCAPES = "soundscapes"

    // Settings
    const val SETTINGS = "settings"
    const val THEME_PICKER = "theme_picker"
    const val BACKUP = "backup"
}

/**
 * Bottom navigation destinations.
 */
data class BottomNavItem(
    val route: String,
    val label: String,
    val iconRes: String, // In production, use actual icon resources
)

val bottomNavItems = listOf(
    BottomNavItem(Routes.HOME, "Home", "home"),
    BottomNavItem(Routes.FOCUS, "Focus", "timer"),
    BottomNavItem(Routes.PLANNER, "Planner", "calendar"),
    BottomNavItem(Routes.PRACTICE, "Practice", "quiz"),
    BottomNavItem(Routes.REVISION, "Revision", "book"),
)
