package com.sankalp.jee.service

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Helper for querying screen time data via UsageStatsManager.
 * Requires PACKAGE_USAGE_STATS permission (granted via Settings).
 */
@Singleton
class ScreenTimeHelper @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    data class AppUsageInfo(
        val packageName: String,
        val appName: String,
        val totalTimeMs: Long,
        val lastTimeUsed: Long,
    )

    /**
     * Get screen time data for today.
     */
    fun getTodayUsage(): List<AppUsageInfo> {
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return emptyList()

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val beginTime = calendar.timeInMillis
        val endTime = System.currentTimeMillis()

        val stats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY, beginTime, endTime
        ) ?: return emptyList()

        val pm = context.packageManager
        return stats
            .filter { it.totalTimeInForeground > 0 }
            .map { stat ->
                val appName = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(stat.packageName, 0)).toString()
                } catch (e: PackageManager.NameNotFoundException) {
                    stat.packageName
                }
                AppUsageInfo(
                    packageName = stat.packageName,
                    appName = appName,
                    totalTimeMs = stat.totalTimeInForeground,
                    lastTimeUsed = stat.lastTimeUsed,
                )
            }
            .sortedByDescending { it.totalTimeMs }
    }

    /**
     * Get all installed apps for the block list.
     */
    fun getInstalledApps(): List<Pair<String, String>> {
        val pm = context.packageManager
        return pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { app ->
                pm.getLaunchIntentForPackage(app.packageName) != null &&
                app.packageName != context.packageName
            }
            .map { app ->
                val label = pm.getApplicationLabel(app).toString()
                app.packageName to label
            }
            .sortedBy { it.second }
    }
}
