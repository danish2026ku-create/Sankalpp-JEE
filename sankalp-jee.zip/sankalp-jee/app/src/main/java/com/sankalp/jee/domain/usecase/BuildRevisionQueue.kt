package com.sankalp.jee.domain.usecase

import com.sankalp.jee.domain.model.Chapter
import com.sankalp.jee.domain.model.Flashcard
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.domain.model.TopicStatus

/**
 * Builds a revision queue by combining:
 *   1. Overdue flashcards (from SM-2).
 *   2. Chapters marked as LEARNED or PRACTICED (need consolidation).
 *   3. Chapters not yet MASTERED with high weightage (priority revision).
 *
 * Output: an ordered list of revision items, most urgent first.
 */
object BuildRevisionQueue {

    sealed class RevisionItem {
        abstract val priority: Int   // Lower = more urgent

        data class FlashcardReview(
            val card: Flashcard,
            override val priority: Int,
        ) : RevisionItem()

        data class ChapterRevision(
            val chapter: Chapter,
            override val priority: Int,
            val reason: String,
        ) : RevisionItem()
    }

    /**
     * Build the full revision queue.
     *
     * @param flashcards  All flashcards (filtering for due ones).
     * @param chapters    All chapters (for consolidation revision).
     * @param now         Current time in millis.
     * @return Ordered list of revision items.
     */
    fun build(
        flashcards: List<Flashcard>,
        chapters: List<Chapter>,
        now: Long = System.currentTimeMillis(),
    ): List<RevisionItem> {
        val items = mutableListOf<RevisionItem>()

        // 1. Overdue flashcards — highest urgency
        val dueCards = SpacedRepetitionEngine.getDueCards(flashcards, now)
        dueCards.forEachIndexed { index, card ->
            items.add(
                RevisionItem.FlashcardReview(
                    card = card,
                    priority = index,  // Most overdue first
                )
            )
        }

        // 2. Chapters that need consolidation
        chapters.forEach { chapter ->
            when {
                // Mastered chapters can wait
                chapter.status == TopicStatus.MASTERED -> { /* Skip */ }

                // High weightage + learned/practiced → urgent revision
                chapter.status in listOf(TopicStatus.LEARNED, TopicStatus.PRACTICED) &&
                        chapter.weightage.weight >= 2 -> {
                    items.add(
                        RevisionItem.ChapterRevision(
                            chapter = chapter,
                            priority = dueCards.size + chapter.weightage.weight,
                            reason = "High-weightage chapter needs consolidation",
                        )
                    )
                }

                // In-progress high-weightage → needs more practice
                chapter.status == TopicStatus.IN_PROGRESS &&
                        chapter.weightage.weight >= 3 -> {
                    items.add(
                        RevisionItem.ChapterRevision(
                            chapter = chapter,
                            priority = dueCards.size + 10,
                            reason = "High-weightage chapter still in progress",
                        )
                    )
                }

                // Practiced but not mastered → general revision
                chapter.status == TopicStatus.PRACTICED -> {
                    items.add(
                        RevisionItem.ChapterRevision(
                            chapter = chapter,
                            priority = dueCards.size + 20,
                            reason = "Needs revision for mastery",
                        )
                    )
                }

                // Learned → needs practice
                chapter.status == TopicStatus.LEARNED -> {
                    items.add(
                        RevisionItem.ChapterRevision(
                            chapter = chapter,
                            priority = dueCards.size + 25,
                            reason = "Learned but needs more practice",
                        )
                    )
                }
            }
        }

        return items.sortedBy { it.priority }
    }

    /**
     * Get only due flashcards, filtered by subject.
     */
    fun dueCardsForSubject(
        flashcards: List<Flashcard>,
        subject: Subject,
        now: Long = System.currentTimeMillis(),
    ): List<Flashcard> = SpacedRepetitionEngine.getDueCards(
        flashcards.filter { it.subject == subject }, now
    )

    /**
     * Count total revision items for a quick badge.
     */
    fun countDue(
        flashcards: List<Flashcard>,
        chapters: List<Chapter>,
        now: Long = System.currentTimeMillis(),
    ): Int = build(flashcards, chapters, now).size
}
