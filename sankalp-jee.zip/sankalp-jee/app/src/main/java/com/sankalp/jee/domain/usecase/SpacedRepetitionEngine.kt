package com.sankalp.jee.domain.usecase

import com.sankalp.jee.domain.model.Flashcard
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * SM-2 (SuperMemo 2) spaced-repetition algorithm.
 *
 * Quality ratings:
 *   0 — Blackout; complete failure.
 *   1 — Almost entirely wrong.
 *   2 — Barely correct after hesitation.
 *   3 — Significant difficulty but eventually correct.
 *   4 — Moderate hesitation; correct.
 *   5 — Perfect, immediate recall.
 *
 * For the simplified 3-button UI:
 *   "Again"  → quality 1
 *   "Good"   → quality 4
 *   "Easy"   → quality 5
 */
object SpacedRepetitionEngine {

    /**
     * Compute the next review schedule for a card after a review.
     *
     * @param card    The current card state.
     * @param quality The quality rating (0–5).
     * @param now     Current time in millis (injectable for testing).
     * @return A new Flashcard with updated SM-2 fields.
     */
    fun schedule(
        card: Flashcard,
        quality: Int,
        now: Long = System.currentTimeMillis(),
    ): Flashcard {
        require(quality in 0..5) { "Quality must be 0..5, got $quality" }

        var ef = card.easeFactor
        var interval = card.interval
        var reps = card.repetitions

        if (quality < 3) {
            // Failed — reset repetitions and interval.
            reps = 0
            interval = 1
        } else {
            // Success — grow the interval.
            reps += 1
            interval = when (reps) {
                1 -> 1       // First success → 1 day
                2 -> 6       // Second success → 6 days
                else -> (interval * ef).toInt() // Subsequent → interval × EF
            }
        }

        // Update ease factor: EF' = EF + (0.1 - (5-q)*(0.08 + (5-q)*0.02))
        ef = max(1.3f, ef + (0.1f - (5 - quality) * (0.08f + (5 - quality) * 0.02f)))

        val nextReview = now + TimeUnit.DAYS.toMillis(interval.toLong())

        return card.copy(
            easeFactor = ef,
            interval = interval,
            repetitions = reps,
            nextReview = nextReview,
            lastReview = now,
        )
    }

    /**
     * Quick scheduling for the 3-button UI.
     */
    fun scheduleAgain(card: Flashcard, now: Long = System.currentTimeMillis()): Flashcard =
        schedule(card, quality = 1, now)

    fun scheduleGood(card: Flashcard, now: Long = System.currentTimeMillis()): Flashcard =
        schedule(card, quality = 4, now)

    fun scheduleEasy(card: Flashcard, now: Long = System.currentTimeMillis()): Flashcard =
        schedule(card, quality = 5, now)

    /**
     * Count how many cards are due for review.
     */
    fun countDue(cards: List<Flashcard>, now: Long = System.currentTimeMillis()): Int =
        cards.count { it.nextReview <= now }

    /**
     * Get cards sorted by urgency (most overdue first).
     */
    fun getDueCards(cards: List<Flashcard>, now: Long = System.currentTimeMillis()): List<Flashcard> =
        cards.filter { it.nextReview <= now }.sortedBy { it.nextReview }
}
