package com.sankalp.jee.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sankalp.jee.domain.model.MockTest

@Entity(tableName = "mock_tests")
data class MockTestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val testName: String,
    val takenAt: Long,
    val totalQuestions: Int = 75,
    val attempted: Int = 0,
    val correct: Int = 0,
    val incorrect: Int = 0,
    val physicsCorrect: Int = 0,
    val physicsTotal: Int = 25,
    val chemistryCorrect: Int = 0,
    val chemistryTotal: Int = 25,
    val mathsCorrect: Int = 0,
    val mathsTotal: Int = 25,
    val totalMarks: Float = 0f,
    val maxMarks: Float = 300f,
    val timeTakenMin: Int = 180,
) {
    fun toDomain() = MockTest(
        id = id, testName = testName, takenAt = takenAt,
        totalQuestions = totalQuestions, attempted = attempted,
        correct = correct, incorrect = incorrect,
        physicsCorrect = physicsCorrect, physicsTotal = physicsTotal,
        chemistryCorrect = chemistryCorrect, chemistryTotal = chemistryTotal,
        mathsCorrect = mathsCorrect, mathsTotal = mathsTotal,
        totalMarks = totalMarks, maxMarks = maxMarks, timeTakenMin = timeTakenMin,
    )

    companion object {
        fun fromDomain(m: MockTest) = MockTestEntity(
            id = m.id, testName = m.testName, takenAt = m.takenAt,
            totalQuestions = m.totalQuestions, attempted = m.attempted,
            correct = m.correct, incorrect = m.incorrect,
            physicsCorrect = m.physicsCorrect, physicsTotal = m.physicsTotal,
            chemistryCorrect = m.chemistryCorrect, chemistryTotal = m.chemistryTotal,
            mathsCorrect = m.mathsCorrect, mathsTotal = m.mathsTotal,
            totalMarks = m.totalMarks, maxMarks = m.maxMarks, timeTakenMin = m.timeTakenMin,
        )
    }
}
