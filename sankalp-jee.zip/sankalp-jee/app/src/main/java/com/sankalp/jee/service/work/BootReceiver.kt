package com.sankalp.jee.service.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.*
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Boot Receiver — re-schedules all periodic workers after device reboot.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            scheduleWorkers(context)
        }
    }

    companion object {
        fun scheduleWorkers(context: Context) {
            val workManager = WorkManager.getInstance(context)

            // Daily Pulse — runs once a day in the evening
            val dailyPulseRequest = PeriodicWorkRequestBuilder<DailyPulseWorker>(
                1, TimeUnit.DAYS
            ).setInitialDelay(calculateDelayUntil(20, 0), TimeUnit.MILLISECONDS) // 8 PM
                .setConstraints(
                    Constraints.Builder()
                        .setRequiresBatteryNotLow(true)
                        .build()
                )
                .build()

            // Revision Reminder — runs at 6 PM
            val revisionReminderRequest = PeriodicWorkRequestBuilder<RevisionReminderWorker>(
                1, TimeUnit.DAYS
            ).setInitialDelay(calculateDelayUntil(18, 0), TimeUnit.MILLISECONDS) // 6 PM
                .setConstraints(
                    Constraints.Builder()
                        .setRequiresBatteryNotLow(true)
                        .build()
                )
                .build()

            // Streak Guard — runs at 11:55 PM
            val streakGuardRequest = PeriodicWorkRequestBuilder<StreakGuardWorker>(
                1, TimeUnit.DAYS
            ).setInitialDelay(calculateDelayUntil(23, 55), TimeUnit.MILLISECONDS)
                .build()

            workManager.enqueueUniquePeriodicWork(
                DailyPulseWorker.WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                dailyPulseRequest,
            )
            workManager.enqueueUniquePeriodicWork(
                RevisionReminderWorker.WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                revisionReminderRequest,
            )
            workManager.enqueueUniquePeriodicWork(
                StreakGuardWorker.WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                streakGuardRequest,
            )
        }

        private fun calculateDelayUntil(hour: Int, minute: Int): Long {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (target.before(now)) target.add(Calendar.DAY_OF_YEAR, 1)
            return target.timeInMillis - now.timeInMillis
        }
    }
}
