package com.sankalp.jee.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sankalp.jee.domain.model.Note
import com.sankalp.jee.domain.model.Subject

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val subject: String? = null,
    val chapterId: Long? = null,
    val isFormula: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
) {
    fun toDomain() = Note(
        id = id, title = title, content = content,
        subject = subject?.let { runCatching { Subject.valueOf(it) }.getOrNull() },
        chapterId = chapterId, isFormula = isFormula,
        createdAt = createdAt, updatedAt = updatedAt,
    )

    companion object {
        fun fromDomain(n: Note) = NoteEntity(
            id = n.id, title = n.title, content = n.content,
            subject = n.subject?.name, chapterId = n.chapterId,
            isFormula = n.isFormula, createdAt = n.createdAt, updatedAt = n.updatedAt,
        )
    }
}
