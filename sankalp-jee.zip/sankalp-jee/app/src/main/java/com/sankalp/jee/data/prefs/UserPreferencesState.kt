package com.sankalp.jee.data.prefs

import com.sankalp.jee.domain.model.FocusMode
import com.sankalp.jee.domain.model.Subject
import com.sankalp.jee.domain.model.ThemeId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

/**
 * A single combined state snapshot of all user preferences.
 * Useful for injecting into ViewModels as a single Flow.
 */
data class UserPreferencesState(
    val onboardingComplete: Boolean = false,
    val examDateMillis: Long? = null,
    val selectedSubjects: Set<Subject> = emptySet(),
    val themeId: ThemeId = ThemeId.MIDNIGHT_LIBRARY,
    val focusMode: FocusMode = FocusMode.STANDARD,
    val focusDurationMin: Int = 52,
    val shortBreakMin: Int = 10,
    val longBreakMin: Int = 20,
    val blockedPackages: Set<String> = emptySet(),
    val strictMode: Boolean = false,
    val notificationGuard: Boolean = false,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val totalFocusMinutes: Long = 0L,
    val musicVolume: Float = 0.5f,
    val soundscapeId: String? = null,
    val autoFocusEnabled: Boolean = false,
    val autoFocusStartHour: Int = 6,
    val autoFocusEndHour: Int = 22,
) {
    /** Days remaining until exam. */
    val daysUntilExam: Int?
        get() = examDateMillis?.let { exam ->
            val diff = exam - System.currentTimeMillis()
            if (diff > 0) (diff / (1000L * 60 * 60 * 24)).toInt() + 1 else null
        }
}

/**
 * Extension: combine all preference flows into a single state flow.
 */
fun UserPreferencesRepository.asState(): Flow<UserPreferencesState> = combine(
    onboardingComplete,
    examDateMillis,
    selectedSubjects,
    themeId,
    focusMode,
    focusDurationMin,
    shortBreakMin,
    longBreakMin,
    blockedPackages,
    strictMode,
    notificationGuard,
    currentStreak,
    longestStreak,
    totalFocusMinutes,
    musicVolume,
    soundscapeId,
    autoFocusEnabled,
    autoFocusStartHour,
    autoFocusEndHour,
) { values ->
    @Suppress("UNCHECKED_CAST")
    UserPreferencesState(
        onboardingComplete = values[0] as Boolean,
        examDateMillis = values[1] as Long?,
        selectedSubjects = values[2] as Set<Subject>,
        themeId = values[3] as ThemeId,
        focusMode = values[4] as FocusMode,
        focusDurationMin = values[5] as Int,
        shortBreakMin = values[6] as Int,
        longBreakMin = values[7] as Int,
        blockedPackages = values[8] as Set<String>,
        strictMode = values[9] as Boolean,
        notificationGuard = values[10] as Boolean,
        currentStreak = values[11] as Int,
        longestStreak = values[12] as Int,
        totalFocusMinutes = values[13] as Long,
        musicVolume = values[14] as Float,
        soundscapeId = values[15] as String?,
        autoFocusEnabled = values[16] as Boolean,
        autoFocusStartHour = values[17] as Int,
        autoFocusEndHour = values[18] as Int,
    )
}
