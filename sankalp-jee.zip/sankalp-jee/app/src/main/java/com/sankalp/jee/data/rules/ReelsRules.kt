package com.sankalp.jee.data.rules

/**
 * Configurable view-id table for detecting Reels/Shorts across apps.
 *
 * The Guardian Service uses this to identify when the user is scrolling
 * through short-form video content and intervene accordingly.
 */
object ReelsRules {

    data class Rule(
        val packageName: String,
        val appName: String,
        val viewIds: List<String>,      // View IDs that indicate the reels view
        val activityNames: List<String>, // Activity class names that host reels
    )

    val rules: List<Rule> = listOf(
        Rule(
            packageName = "com.instagram.android",
            appName = "Instagram",
            viewIds = listOf("reels_viewer", "reel_timestamp"),
            activityNames = listOf("com.instagram.mainactivity.MainActivity"),
        ),
        Rule(
            packageName = "com.google.android.apps.youtube.app",
            appName = "YouTube Shorts",
            viewIds = listOf("shorts_video_container"),
            activityNames = listOf("com.google.android.apps.youtube.app.activity.WatchWhileActivity"),
        ),
        Rule(
            packageName = "com.facebook.katana",
            appName = "Facebook Reels",
            viewIds = listOf("reels_container", "reels_root"),
            activityNames = listOf("com.facebook.katana.activity.FbMainTabActivity"),
        ),
        Rule(
            packageName = "com.zhiliaoapp.musically",
            appName = "TikTok",
            viewIds = listOf("video_view", "feed_container"),
            activityNames = listOf("com.ss.android.ugc.aweme.splash.SplashActivity"),
        ),
        Rule(
            packageName = "com.snapchat.android",
            appName = "Snapchat Spotlight",
            viewIds = listOf("spotlight_container"),
            activityNames = listOf("com.snapchat.android.LandingPageActivity"),
        ),
        Rule(
            packageName = "org.telegram.messenger",
            appName = "Telegram Stories",
            viewIds = listOf("story_viewer"),
            activityNames = listOf("org.telegram.ui.LaunchActivity"),
        ),
    )

    fun findRule(packageName: String): Rule? = rules.find { it.packageName == packageName }
}
