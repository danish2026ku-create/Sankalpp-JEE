package com.sankalp.jee.ui.screens.planner

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sankalp.jee.ui.components.*
import com.sankalp.jee.ui.theme.SankalpTheme

@Composable
fun SyllabusScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Syllabus Tracker") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } })
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item { Text("Track your progress through all JEE chapters.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item { Spacer(Modifier.height(8.dp)) }
            item { SubjectPill(subject = com.sankalp.jee.domain.model.Subject.PHYSICS) }
            item { EmptyState(emoji = "📊", message = "21 Physics chapters") }
            item { SubjectPill(subject = com.sankalp.jee.domain.model.Subject.CHEMISTRY) }
            item { EmptyState(emoji = "📊", message = "23 Chemistry chapters") }
            item { SubjectPill(subject = com.sankalp.jee.domain.model.Subject.MATHEMATICS) }
            item { EmptyState(emoji = "📊", message = "18 Mathematics chapters") }
        }
    }
}

@Composable
fun BacklogScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Backlog") }, navigationIcon = { TextButton(onClick = onBack) { Text("←") } })
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            EmptyState(emoji = "📦", message = "Overdue tasks will appear here.\nStay on top of your backlog!")
        }
    }
}
