package com.sankalp.jee.domain.model

/**
 * A study task in the planner.
 *
 * @property id           Unique row ID.
 * @property title        Task description.
 * @property subject      Linked subject.
 * @property chapterId    Optional linked chapter.
 * @property date         Planned date as epoch millis (start of day).
 * @property estimatedMin Estimated minutes to complete.
 * @property actualMin    Actual minutes spent (null if not started).
 * @property isDone       Whether the task is completed.
 * @property priority     1 = high, 2 = medium, 3 = low.
 * @property createdAt    Epoch millis when created.
 */
data class StudyTask(
    val id: Long = 0,
    val title: String,
    val subject: Subject,
    val chapterId: Long? = null,
    val date: Long,
    val estimatedMin: Int = 45,
    val actualMin: Int? = null,
    val isDone: Boolean = false,
    val priority: Int = 2,
    val createdAt: Long = System.currentTimeMillis(),
)
