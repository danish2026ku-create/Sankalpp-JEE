package com.sankalp.jee.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.math.sin
import kotlin.random.Random

/**
 * Live animated backgrounds for each theme.
 * These run as Canvas animations behind all screens.
 *
 * Respects the "reduced motion" system flag — when enabled,
 * backgrounds freeze on the first frame.
 */
@Composable
fun LiveBackground(
    style: LiveBackgroundStyle,
    modifier: Modifier = Modifier,
    primary: Color = MaterialTheme_color_primary(),
    accent: Color = SankalpTheme.colors.themeAccent,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "bg")

    when (style) {
        LiveBackgroundStyle.STARFIELD -> StarfieldBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.RISING_GRADIENT -> RisingGradientBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.RAIN_STREAKS -> RainStreaksBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.GOLDEN_AURORA -> GoldenAuroraBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.BLUE_AURORA -> BlueAuroraBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.LEAF_SHADOW -> LeafShadowBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.PAPER_GRAIN -> PaperGrainBackground(modifier)
        LiveBackgroundStyle.AURORA_RIBBONS -> AuroraRibbonsBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.WARM_HAZE -> WarmHazeBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.EMERALD_PULSE -> EmeraldPulseBackground(infiniteTransition, primary, accent, modifier)
        LiveBackgroundStyle.NONE -> {}
    }
}

// ──────────────────────────────────────────────
//  Background implementations
// ──────────────────────────────────────────────

@Composable
private fun StarfieldBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val twinkle by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3000), RepeatMode.Reverse),
        label = "twinkle",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val stars = remember_stars()
        stars.forEach { star ->
            val alpha = (0.3f + 0.7f * sin((twinkle + star.phase) * Math.PI.toFloat()) * 0.5f + 0.5f)
                .coerceIn(0.1f, 1f)
            drawCircle(
                color = if (star.isAccent) accent else primary,
                radius = star.radius,
                center = star.position,
                alpha = alpha * star.alpha,
            )
        }
    }
}

@Composable
private fun RisingGradientBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val offset by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(8000), RepeatMode.Restart),
        label = "rising",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    accent.copy(alpha = 0.08f + 0.05f * offset),
                    primary.copy(alpha = 0.03f),
                    Color.Transparent,
                ),
                startY = size.height * (1f - offset),
                endY = size.height,
            )
        )
    }
}

@Composable
private fun RainStreaksBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val progress by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2000), RepeatMode.Restart),
        label = "rain",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val streaks = remember_rain_streaks()
        streaks.forEach { streak ->
            val y = ((progress + streak.offset) % 1f) * size.height * 1.2f - size.height * 0.1f
            drawLine(
                color = primary.copy(alpha = streak.alpha * 0.3f),
                start = Offset(streak.x * size.width, y),
                end = Offset(streak.x * size.width, y + streak.length),
                strokeWidth = 1f,
            )
        }
    }
}

@Composable
private fun GoldenAuroraBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 6.28f,
        animationSpec = infiniteRepeatable(tween(10000), RepeatMode.Restart),
        label = "aurora",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val centerY = size.height * 0.3f
        val amplitude = size.height * 0.1f

        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    primary.copy(alpha = 0.12f + 0.05f * sin(phase).toFloat()),
                    accent.copy(alpha = 0.06f),
                    Color.Transparent,
                ),
                center = Offset(size.width * 0.5f, centerY + amplitude * sin(phase).toFloat()),
                radius = size.width * 0.6f,
            )
        )
    }
}

@Composable
private fun BlueAuroraBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 6.28f,
        animationSpec = infiniteRepeatable(tween(12000), RepeatMode.Restart),
        label = "blue_auroa",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    accent.copy(alpha = 0.1f + 0.05f * sin(phase).toFloat()),
                    primary.copy(alpha = 0.06f),
                    Color.Transparent,
                )
            )
        )
    }
}

@Composable
private fun LeafShadowBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val sway by transition.animateFloat(
        initialValue = -0.05f, targetValue = 0.05f,
        animationSpec = infiniteRepeatable(tween(6000), RepeatMode.Reverse),
        label = "sway",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    primary.copy(alpha = 0.06f),
                    Color.Transparent,
                ),
                center = Offset(size.width * (0.5f + sway), size.height * 0.3f),
                radius = size.width * 0.5f,
            )
        )
    }
}

@Composable
private fun PaperGrainBackground(modifier: Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        // Subtle noise texture for paper feel
        val grain = remember_grain()
        grain.forEach { point ->
            drawCircle(
                color = Color.Black.copy(alpha = point.alpha * 0.02f),
                radius = 0.5f,
                center = point.offset,
            )
        }
    }
}

@Composable
private fun AuroraRibbonsBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 6.28f,
        animationSpec = infiniteRepeatable(tween(15000), RepeatMode.Restart),
        label = "ribbons",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        for (i in 0..2) {
            val ribbonPhase = phase + i * 2.09f
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        if (i % 2 == 0) primary.copy(alpha = 0.08f + 0.04f * sin(ribbonPhase).toFloat())
                        else accent.copy(alpha = 0.06f + 0.03f * sin(ribbonPhase).toFloat()),
                        Color.Transparent,
                    ),
                    startY = size.height * (0.2f + 0.1f * sin(ribbonPhase).toFloat()),
                    endY = size.height * (0.6f + 0.1f * sin(ribbonPhase + 1f).toFloat()),
                )
            )
        }
    }
}

@Composable
private fun WarmHazeBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val pulse by transition.animateFloat(
        initialValue = 0.8f, targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(8000), RepeatMode.Reverse),
        label = "haze",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    primary.copy(alpha = 0.08f * pulse),
                    accent.copy(alpha = 0.04f),
                    Color.Transparent,
                ),
                center = Offset(size.width * 0.5f, size.height * 0.4f),
                radius = size.width * 0.7f,
            )
        )
    }
}

@Composable
private fun EmeraldPulseBackground(
    transition: InfiniteTransition,
    primary: Color,
    accent: Color,
    modifier: Modifier,
) {
    val pulse by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4000), RepeatMode.Reverse),
        label = "pulse",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    primary.copy(alpha = 0.08f * (0.5f + 0.5f * pulse)),
                    Color.Transparent,
                ),
            ),
            center = Offset(size.width * 0.5f, size.height * 0.5f),
            radius = size.width * 0.4f * (0.8f + 0.2f * pulse),
        )
    }
}

// ──────────────────────────────────────────────
//  Helper composables (pseudo-data holders)
// ──────────────────────────────────────────────

@Composable
private fun MaterialTheme_color_primary(): Color = MaterialTheme.colorScheme.primary

private data class Star(val position: Offset, val radius: Float, val alpha: Float, val phase: Float, val isAccent: Boolean)

@Composable
private fun remember_stars(): List<Star> {
    return androidx.compose.runtime.remember {
        List(80) {
            Star(
                position = Offset(Random.nextFloat() * 1000f, Random.nextFloat() * 2000f),
                radius = Random.nextFloat() * 2f + 0.5f,
                alpha = Random.nextFloat() * 0.6f + 0.2f,
                phase = Random.nextFloat() * 6.28f,
                isAccent = Random.nextFloat() > 0.7f,
            )
        }
    }
}

private data class RainStreak(val x: Float, val offset: Float, val alpha: Float, val length: Float)

@Composable
private fun remember_rain_streaks(): List<RainStreak> {
    return androidx.compose.runtime.remember {
        List(40) {
            RainStreak(
                x = Random.nextFloat(),
                offset = Random.nextFloat(),
                alpha = Random.nextFloat() * 0.5f + 0.1f,
                length = Random.nextFloat() * 40f + 20f,
            )
        }
    }
}

private data class GrainPoint(val offset: Offset, val alpha: Float)

@Composable
private fun remember_grain(): List<GrainPoint> {
    return androidx.compose.runtime.remember {
        List(200) {
            GrainPoint(
                offset = Offset(Random.nextFloat() * 1000f, Random.nextFloat() * 2000f),
                alpha = Random.nextFloat() * 0.8f + 0.2f,
            )
        }
    }
}
