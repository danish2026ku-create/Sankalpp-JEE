package com.sankalp.jee.domain.usecase

import com.sankalp.jee.domain.model.MockTest
import com.sankalp.jee.domain.model.Subject
import kotlin.math.max

/**
 * Rank Estimator — predicts JEE rank based on mock test performance trends.
 *
 * Uses a simplified model:
 *   - Takes the rolling average of the last N mock tests.
 *   - Maps marks percentile to an estimated rank range.
 *   - Accounts for accuracy and attempt rate as tiebreakers.
 *
 * Approximate candidates: ~12,00,000 (1.2 million) for JEE Main.
 */
object RankEstimator {

    data class RankEstimate(
        val estimatedRank: Int,
        val rankRange: IntRange,
        val percentile: Float,
        val confidence: String,       // "Low", "Medium", "High"
        val subjectBreakdown: Map<Subject, Float>,  // Subject → estimated percentile
        val trend: Trend,             // Improving / Stable / Declining
    )

    enum class Trend { IMPROVING, STABLE, DECLINING }

    /**
     * Estimate rank from a list of mock test results (most recent last).
     */
    fun estimate(
        mockTests: List<MockTest>,
        totalCandidates: Int = 12_00_000,
    ): RankEstimate? {
        if (mockTests.isEmpty()) return null

        val recent = mockTests.takeLast(5)  // Rolling window of 5

        // Overall marks percentage (rolling average)
        val avgMarksPct = recent.map { it.totalMarks / max(it.maxMarks, 1f) }.average().toFloat()

        // Map percentile to rank
        val percentile = marksToPercentile(avgMarksPct)
        val estimatedRank = percentileToRank(percentile, totalCandidates)

        // Rank range (±15% uncertainty)
        val uncertainty = (estimatedRank * 0.15f).toInt().coerceAtLeast(500)
        val rankRange = (estimatedRank - uncertainty).coerceAtLeast(1)..
                (estimatedRank + uncertainty).coerceAtMost(totalCandidates)

        // Confidence based on sample size and consistency
        val confidence = when {
            recent.size >= 5 && recent.map { it.totalMarks }.standardDeviation() < 15 -> "High"
            recent.size >= 3 -> "Medium"
            else -> "Low"
        }

        // Per-subject percentiles
        val subjectBreakdown = mapOf(
            Subject.PHYSICS to recent.map {
                it.physicsCorrect.toFloat() / max(it.physicsTotal, 1)
            }.average().toFloat().let { marksToPercentile(it * 0.35f) },
            Subject.CHEMISTRY to recent.map {
                it.chemistryCorrect.toFloat() / max(it.chemistryTotal, 1)
            }.average().toFloat().let { marksToPercentile(it * 0.35f) },
            Subject.MATHEMATICS to recent.map {
                it.mathsCorrect.toFloat() / max(it.mathsTotal, 1)
            }.average().toFloat().let { marksToPercentile(it * 0.35f) },
        )

        // Trend detection
        val trend = detectTrend(recent)

        return RankEstimate(
            estimatedRank = estimatedRank,
            rankRange = rankRange,
            percentile = percentile,
            confidence = confidence,
            subjectBreakdown = subjectBreakdown,
            trend = trend,
        )
    }

    /**
     * Convert marks percentage (0–1) to a percentile (0–100).
     * Based on historical JEE Main score→percentile mapping.
     */
    private fun marksToPercentile(marksFraction: Float): Float {
        // Approximate mapping (tuned from recent years' data)
        return when {
            marksFraction >= 0.75f -> 99.5f + (marksFraction - 0.75f) * 2f
            marksFraction >= 0.55f -> 97f + (marksFraction - 0.55f) * 12.5f
            marksFraction >= 0.40f -> 92f + (marksFraction - 0.40f) * 33f
            marksFraction >= 0.30f -> 85f + (marksFraction - 0.30f) * 70f
            marksFraction >= 0.20f -> 72f + (marksFraction - 0.20f) * 130f
            marksFraction >= 0.10f -> 55f + (marksFraction - 0.10f) * 170f
            else -> (marksFraction * 550f).coerceAtLeast(0f)
        }.coerceIn(0f, 99.99f)
    }

    /**
     * Convert percentile to estimated rank.
     */
    private fun percentileToRank(percentile: Float, totalCandidates: Int): Int {
        val fraction = (100f - percentile) / 100f
        return (fraction * totalCandidates).toInt().coerceAtLeast(1)
    }

    /**
     * Detect whether scores are improving, stable, or declining.
     */
    private fun detectTrend(mockTests: List<MockTest>): Trend {
        if (mockTests.size < 3) return Trend.STABLE

        val marks = mockTests.takeLast(3).map { it.totalMarks }
        val first = marks.first()
        val last = marks.last()
        val diff = last - first

        return when {
            diff > 10 -> Trend.IMPROVING
            diff < -10 -> Trend.DECLINING
            else -> Trend.STABLE
        }
    }

    private fun List<Float>.standardDeviation(): Float {
        if (size < 2) return 0f
        val mean = average().toFloat()
        val variance = sumOf { (it - mean) * (it - mean) } / (size - 1)
        return kotlin.math.sqrt(variance).toFloat()
    }
}
