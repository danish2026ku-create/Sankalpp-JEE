package com.sankalp.jee.data.local

import androidx.room.*
import com.sankalp.jee.data.local.entities.*
import kotlinx.coroutines.flow.Flow

/**
 * Single DAO for the entire Sankalp database.
 * All reads that the UI observes are exposed as Flow.
 */
@Dao
interface SankalpDao {

    // ──────────────────────────────────────────────
    //  Focus Sessions
    // ──────────────────────────────────────────────

    @Query("SELECT * FROM focus_sessions ORDER BY startedAt DESC")
    fun getAllFocusSessions(): Flow<List<FocusSessionEntity>>

    @Query("SELECT * FROM focus_sessions WHERE startedAt >= :startOfDay AND startedAt < :endOfDay ORDER BY startedAt DESC")
    fun getFocusSessionsForDay(startOfDay: Long, endOfDay: Long): Flow<List<FocusSessionEntity>>

    @Query("SELECT COALESCE(SUM(durationSec), 0) FROM focus_sessions WHERE startedAt >= :startOfDay AND startedAt < :endOfDay")
    fun getTotalFocusSecondsForDay(startOfDay: Long, endOfDay: Long): Flow<Long>

    @Query("SELECT COALESCE(SUM(durationSec), 0) FROM focus_sessions WHERE startedAt >= :startOfWeek")
    fun getTotalFocusSecondsSince(startOfWeek: Long): Flow<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFocusSession(session: FocusSessionEntity): Long

    // ──────────────────────────────────────────────
    //  Study Tasks
    // ──────────────────────────────────────────────

    @Query("SELECT * FROM study_tasks WHERE date >= :startOfDay AND date < :endOfDay ORDER BY priority ASC, createdAt ASC")
    fun getTasksForDay(startOfDay: Long, endOfDay: Long): Flow<List<StudyTaskEntity>>

    @Query("SELECT * FROM study_tasks WHERE isDone = 0 ORDER BY date ASC, priority ASC")
    fun getPendingTasks(): Flow<List<StudyTaskEntity>>

    @Query("SELECT * FROM study_tasks WHERE isDone = 0 AND date < :today")
    fun getBacklogTasks(today: Long): Flow<List<StudyTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: StudyTaskEntity): Long

    @Update
    suspend fun updateTask(task: StudyTaskEntity)

    @Query("UPDATE study_tasks SET isDone = :done WHERE id = :taskId")
    suspend fun setTaskDone(taskId: Long, done: Boolean)

    @Delete
    suspend fun deleteTask(task: StudyTaskEntity)

    // ──────────────────────────────────────────────
    //  Chapters / Syllabus
    // ──────────────────────────────────────────────

    @Query("SELECT * FROM chapters ORDER BY subject ASC, `order` ASC")
    fun getAllChapters(): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE subject = :subject ORDER BY `order` ASC")
    fun getChaptersForSubject(subject: String): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters WHERE id = :id")
    suspend fun getChapterById(id: Long): ChapterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Query("UPDATE chapters SET status = :status WHERE id = :id")
    suspend fun updateChapterStatus(id: Long, status: String)

    // ──────────────────────────────────────────────
    //  Mock Tests
    // ──────────────────────────────────────────────

    @Query("SELECT * FROM mock_tests ORDER BY takenAt DESC")
    fun getAllMockTests(): Flow<List<MockTestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockTest(mockTest: MockTestEntity): Long

    @Delete
    suspend fun deleteMockTest(mockTest: MockTestEntity)

    // ──────────────────────────────────────────────
    //  Error Book
    // ──────────────────────────────────────────────

    @Query("SELECT * FROM error_entries ORDER BY loggedAt DESC")
    fun getAllErrors(): Flow<List<ErrorEntryEntity>>

    @Query("SELECT * FROM error_entries WHERE isResolved = 0 ORDER BY loggedAt DESC")
    fun getUnresolvedErrors(): Flow<List<ErrorEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertError(error: ErrorEntryEntity): Long

    @Query("UPDATE error_entries SET isResolved = :resolved, reviewCount = reviewCount + 1 WHERE id = :id")
    suspend fun markErrorReviewed(id: Long, resolved: Boolean)

    // ──────────────────────────────────────────────
    //  Flashcards
    // ──────────────────────────────────────────────

    @Query("SELECT * FROM flashcards ORDER BY nextReview ASC")
    fun getAllFlashcards(): Flow<List<FlashcardEntity>>

    @Query("SELECT * FROM flashcards WHERE nextReview <= :now ORDER BY nextReview ASC")
    fun getDueFlashcards(now: Long): Flow<List<FlashcardEntity>>

    @Query("SELECT COUNT(*) FROM flashcards WHERE nextReview <= :now")
    fun countDueFlashcards(now: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcard(card: FlashcardEntity): Long

    @Update
    suspend fun updateFlashcard(card: FlashcardEntity)

    @Delete
    suspend fun deleteFlashcard(card: FlashcardEntity)

    // ──────────────────────────────────────────────
    //  Notes
    // ──────────────────────────────────────────────

    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE isFormula = 1 ORDER BY subject ASC, title ASC")
    fun getFormulaVault(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Delete
    suspend fun deleteNote(note: NoteEntity)
}
