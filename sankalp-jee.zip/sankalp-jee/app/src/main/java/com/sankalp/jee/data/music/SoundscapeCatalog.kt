package com.sankalp.jee.data.music

/**
 * Catalog of bundled soundscapes (raw audio files in res/raw).
 * Each soundscape is a short loopable ambient audio file.
 */
data class Soundscape(
    val id: String,
    val displayName: String,
    val description: String,
    val rawResName: String,   // R.raw.<name>
    val durationSec: Int,
    val category: Category,
) {
    enum class Category { NATURE, URBAN, FOCUSSOUND, BINAURAL }
}

object SoundscapeCatalog {
    val all: List<Soundscape> = listOf(
        Soundscape("rain_window", "Rain on Window", "Gentle rain pattering against glass", "rain_window", 120, Soundscape.Category.NATURE),
        Soundscape("forest_morning", "Forest Morning", "Birds chirping, leaves rustling", "forest_morning", 180, Soundscape.Category.NATURE),
        Soundscape("ocean_waves", "Ocean Waves", "Calm waves rolling on shore", "ocean_waves", 150, Soundscape.Category.NATURE),
        Soundscape("thunder_distant", "Distant Thunder", "Soft thunder rumbling far away", "thunder_distant", 120, Soundscape.Category.NATURE),
        Soundscape("cafe_ambient", "Café Ambience", "Soft murmur of a coffee shop", "cafe_ambient", 180, Soundscape.Category.URBAN),
        Soundscape("library_quiet", "Library Silence", "Pages turning, pencil writing", "library_quiet", 180, Soundscape.Category.FOCUSSOUND),
        Soundscape("keyboard_typing", "Typing Sound", "Mechanical keyboard, steady rhythm", "keyboard_typing", 120, Soundscape.Category.FOCUSSOUND),
        Soundscape("binaural_focus", "Focus Binaural", "14 Hz beta wave binaural beat", "binaural_focus", 300, Soundscape.Category.BINAURAL),
        Soundscape("binaural_calm", "Calm Binaural", "8 Hz alpha wave binaural beat", "binaural_calm", 300, Soundscape.Category.BINAURAL),
        Soundscape("fireplace", "Fireplace", "Crackling wood fire warmth", "fireplace", 180, Soundscape.Category.NATURE),
        Soundscape("wind_chimes", "Wind Chimes", "Gentle chimes in a breeze", "wind_chimes", 120, Soundscape.Category.NATURE),
        Soundscape("night_crickets", "Night Crickets", "Crickets and gentle night air", "night_crickets", 150, Soundscape.Category.NATURE),
    )

    fun findById(id: String): Soundscape? = all.find { it.id == id }
}
