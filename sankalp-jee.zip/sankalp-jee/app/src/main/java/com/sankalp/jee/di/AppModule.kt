package com.sankalp.jee.di

import android.content.Context
import com.sankalp.jee.data.music.MediaStoreAudioSource
import com.sankalp.jee.data.music.MusicRepository
import com.sankalp.jee.data.prefs.UserPreferencesRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideUserPreferencesRepository(
        @ApplicationContext context: Context,
    ): UserPreferencesRepository = UserPreferencesRepository(context)

    @Provides
    @Singleton
    fun provideMusicRepository(
        @ApplicationContext context: Context,
    ): MusicRepository = MusicRepository(context)

    @Provides
    @Singleton
    fun provideMediaStoreAudioSource(
        @ApplicationContext context: Context,
    ): MediaStoreAudioSource = MediaStoreAudioSource(context)
}
