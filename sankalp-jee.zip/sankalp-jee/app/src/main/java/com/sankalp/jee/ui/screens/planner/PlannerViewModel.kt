package com.sankalp.jee.ui.screens.planner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sankalp.jee.data.local.SankalpDao
import com.sankalp.jee.data.local.entities.StudyTaskEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class PlannerUiState(
    val todayTasks: List<StudyTaskEntity> = emptyList(),
    val backlogCount: Int = 0,
    val isLoading: Boolean = true,
)

@HiltViewModel
class PlannerViewModel @Inject constructor(
    private val dao: SankalpDao,
) : ViewModel() {

    private val _state = MutableStateFlow(PlannerUiState())
    val state: StateFlow<PlannerUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            val today = todayStart()
            combine(
                dao.getTasksForDay(today, today + 86400000L),
                dao.getBacklogTasks(today),
            ) { tasks, backlog ->
                PlannerUiState(
                    todayTasks = tasks,
                    backlogCount = backlog.size,
                    isLoading = false,
                )
            }.collect { _state.value = it }
        }
    }

    fun toggleTask(taskId: Long) {
        viewModelScope.launch {
            val task = _state.value.todayTasks.find { it.id == taskId } ?: return@launch
            dao.setTaskDone(taskId, !task.isDone)
        }
    }

    private fun todayStart(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
