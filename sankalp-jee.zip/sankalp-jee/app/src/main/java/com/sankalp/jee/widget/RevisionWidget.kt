package com.sankalp.jee.widget

import android.content.Context
import androidx.glance.*
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.*

class RevisionWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .background(Color(0xFF0E1116)),
                verticalAlignment = Alignment.CenterVertically,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "📚",
                    style = TextStyle(fontSize = 28.sp),
                )
                Text(
                    text = "0 cards due",
                    style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ColorProvider(0xFFFBBF24)),
                )
                Text(
                    text = "Revision",
                    style = TextStyle(fontSize = 12.sp, color = ColorProvider(0xFFE8C49A)),
                )
            }
        }
    }
}

class RevisionWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = RevisionWidget()
}
