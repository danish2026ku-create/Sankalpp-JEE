package com.sankalp.jee.domain.model

/**
 * A flashcard for spaced-repetition revision (SM-2 algorithm).
 *
 * @property id           Unique row ID.
 * @property subject      Subject area.
 * @property chapterId    Optional linked chapter.
 * @property front        Front side text (question / formula).
 * @property back         Back side text (answer / explanation).
 * @property easeFactor   SM-2 ease factor (default 2.5).
 * @property interval     Current interval in days.
 * @property repetitions  Number of successful repetitions.
 * @property nextReview   Epoch millis for next review date.
 * @property lastReview   Epoch millis of last review (null if never).
 * @property createdAt    Epoch millis when created.
 */
data class Flashcard(
    val id: Long = 0,
    val subject: Subject,
    val chapterId: Long? = null,
    val front: String,
    val back: String,
    val easeFactor: Float = 2.5f,
    val interval: Int = 0,
    val repetitions: Int = 0,
    val nextReview: Long = System.currentTimeMillis(),
    val lastReview: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val isDue: Boolean
        get() = nextReview <= System.currentTimeMillis()
}
