package com.sankalp.jee.domain.model

/**
 * Mastery status for a topic in the syllabus tracker.
 */
enum class TopicStatus(val displayName: String, val progress: Float) {
    NOT_STARTED("Not Started", 0f),
    IN_PROGRESS("In Progress", 0.5f),
    LEARNED("Learned", 0.75f),
    PRACTICED("Practiced", 0.9f),
    MASTERED("Mastered", 1.0f);

    val emoji: String
        get() = when (this) {
            NOT_STARTED -> "○"
            IN_PROGRESS -> "◐"
            LEARNED -> "◑"
            PRACTICED -> "●"
            MASTERED -> "★"
        }
}
