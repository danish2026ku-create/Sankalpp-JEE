package com.sankalp.jee.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.sankalp.jee.domain.model.*

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val subject: String,
    val status: String = TopicStatus.NOT_STARTED.name,
    val weightage: String = WeightageTier.MEDIUM.name,
    val order: Int = 0,
) {
    fun toDomain() = Chapter(
        id = id,
        name = name,
        subject = runCatching { Subject.valueOf(subject) }.getOrDefault(Subject.PHYSICS),
        status = runCatching { TopicStatus.valueOf(status) }.getOrDefault(TopicStatus.NOT_STARTED),
        weightage = runCatching { WeightageTier.valueOf(weightage) }.getOrDefault(WeightageTier.MEDIUM),
        order = order,
    )

    companion object {
        fun fromDomain(c: Chapter) = ChapterEntity(
            id = c.id,
            name = c.name,
            subject = c.subject.name,
            status = c.status.name,
            weightage = c.weightage.name,
            order = c.order,
        )
    }
}
